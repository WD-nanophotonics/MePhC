from __future__ import annotations

import math

import meep as mp
from matplotlib import pyplot as plt
from meep import mpb
import numpy as np

from . import lattice as ml
from .berry import BerryCurvatureCalculator
from .efs import EFSResult, plot_efs
from .geometry import to_meep_geometry
from .kspace import (
    HighSymmetryPath,
    square_full_zone_points,
    square_gxm_path,
    triangular_gkm_path,
    triangular_reduced_zone_points,
)
from .plotting import plot_band_path, plot_scalar_field


class Band:
    """Shared 2D MPB interface for triangular and square photonic lattices.

    Physical lengths ``a``, ``r1``, ``r2``, and ``h`` must use one consistent
    unit; frequency conversion assumes ``a`` is in nm. Geometry patterns and
    public k-points use normalized real-space and Cartesian reciprocal-space
    coordinates, respectively.
    """

    def __init__(self, a=400, r1=120, r2=80, n_eff=2.7, h=1000, resolution=128, lattice_type="triangular"):
        self.a = a
        self.r1 = r1
        self.r2 = r2
        self.n_eff = n_eff
        self.h = h
        self.resolution = resolution
        self.lattice_type = self._normalize_lattice_type(lattice_type)
        self.Si = mp.Medium(epsilon=n_eff**2)
        self.geo_latt = self._make_geometry_lattice(self.lattice_type)
        self.Gamma = mp.Vector3()
        if self.lattice_type == "square":
            self.X = mp.Vector3(0.5, 0.0)
            self.M = mp.Vector3(0.5, 0.5)
            self.K = self.M
        else:
            self.M = mp.Vector3(y=0.5)
            self.K = mp.Vector3(1 / 3, 1 / 3)

    @staticmethod
    def _normalize_lattice_type(lattice_type: str) -> str:
        aliases = {
            "triangular": "triangular",
            "tri": "triangular",
            "t": "triangular",
            "honeycomb": "triangular",
            "hon": "triangular",
            "hc": "triangular",
            "h": "triangular",
            "square": "square",
            "sqr": "square",
            "s": "square",
        }
        key = str(lattice_type).lower()
        if key not in aliases:
            raise ValueError("lattice_type must be 'triangular' or 'square'.")
        return aliases[key]

    @staticmethod
    def _make_geometry_lattice(lattice_type: str):
        if lattice_type == "square":
            return mp.Lattice(size=mp.Vector3(1, 1), basis1=mp.Vector3(1, 0), basis2=mp.Vector3(0, 1))
        return mp.Lattice(
            size=mp.Vector3(1, 1),
            basis1=mp.Vector3(0.5, math.sqrt(3) / 2),
            basis2=mp.Vector3(0.5, -math.sqrt(3) / 2),
        )

    def default_path(self) -> HighSymmetryPath:
        """Return Gamma-K-M-Gamma or Gamma-X-M-Gamma for this lattice."""
        if self.lattice_type == "square":
            return square_gxm_path()
        return triangular_gkm_path()

    def create_material_block(self):
        """Return the effective-index background block used by current 2D cases."""
        return [mp.Block(material=self.Si, size=mp.Vector3(mp.inf, mp.inf, self.h))]

    def convert_ndarray_to_meep_geo(self, pattern, material=mp.air, rectify=True, cylinder=0):
        """Convert normalized pattern data into Meep geometry objects.

        ``rectify`` maps vertices through the geometry lattice before MPB use.
        ``cylinder`` is retained for compatibility: a truthy value forces
        cylinders; otherwise shape detection is automatic.
        """
        shape = "cylinder" if cylinder else "auto"
        return to_meep_geometry(
            pattern,
            material=material,
            height=self.h,
            geometry_lattice=self.geo_latt,
            rectify=rectify,
            shape=shape,
        )

    def run_simulation_te(self, pattern, ks, num_b, show_dielectric=False):
        shape = self.convert_ndarray_to_meep_geo(pattern, rectify=True)
        ms = mpb.ModeSolver(
            geometry_lattice=self.geo_latt,
            geometry=self.create_material_block() + shape,
            default_material=mp.air,
            resolution=self.resolution,
            num_bands=num_b,
            k_points=ks,
            verbose=False,
        )
        ms.run_parity(p=mp.TE, reset_fields=True)

        if show_dielectric:
            dis = ms.get_epsilon()
            plt.imshow(dis.T, interpolation="spline36", cmap="binary")
            plt.axis("off")
            plt.show()

            md = mpb.MPBData(rectify=True, resolution=64, periods=3)
            rectangular_data = md.convert(dis)
            plt.imshow(rectangular_data.T, interpolation="spline36", cmap="binary")
            plt.axis("off")
            plt.show()

        return ms.freqs

    def calculate_actual_freqs(self, fs):
        """Convert normalized MPB frequencies to THz using lattice constant ``a``."""
        array = np.asarray(fs)
        result = array * 299792.458 / self.a
        if np.isscalar(fs):
            return float(result)
        return result.tolist()

    def create_unitcell(self, n1, theta1, n2=None, theta2=None, show=True):
        if self.lattice_type == "square":
            lattice = ml.Lattice(
                period=1,
                outline=[(-0.5, -0.5), (0.5, -0.5), (0.5, 0.5), (-0.5, 0.5)],
                orientation=0,
                lattice_type="square",
            )
        elif self.r2 is None:
            lattice = ml.Lattice(period=1, outline=[(-0.1, 0.6), (1, 0.6), (1, 0), (-0.1, 0)], orientation=0, lattice_type="t")
        else:
            lattice = ml.Lattice(period=1, outline=[(-0.1, 0.6), (1, 0.6), (1, 0), (-0.1, 0)], orientation=0, lattice_type="hc")

        if show:
            lattice.preview_lattice(show_outline=True)

        if n2:
            pc = lattice.PolygonPattern(n1, self.r1 / self.a, theta1, n2, self.r2 / self.a, theta2)
        else:
            pc = lattice.PolygonPattern(n1, self.r1 / self.a, theta1)

        if show:
            pc.preview_pattern()

        return pc

    def get_three_bands_at_K(self, pattern, show=False):
        freqs = self.run_simulation_te(pattern, [self.K], 3, show_dielectric=show)
        return self.calculate_actual_freqs(freqs)

    def berry_calculator(self, num_bands=None, geometry=None):
        """Build a Berry calculator using this lattice, material, and resolution."""
        if num_bands is None:
            num_bands = 3
        feature_geometry = [] if geometry is None else list(geometry)
        return BerryCurvatureCalculator(
            geometry=self.create_material_block() + feature_geometry,
            geometry_lattice=self.geo_latt,
            resolution=self.resolution,
            num_bands=num_bands,
            polarization=mp.TE,
            run_band_func=mpb.fix_efield_phase,
            default_material=mp.air,
            verbose=False,
        )

    def calculate_berry_curvature(self, pattern, k_point, step, num_bands, band_index=None):
        """Calculate one plaquette at a Cartesian k-point.

        ``step`` uses the same reciprocal-coordinate units as ``k_point``.
        ``band_index`` is 0-based; ``None`` returns all requested bands.
        """
        geometry = self.convert_ndarray_to_meep_geo(pattern, rectify=True)
        calculator = self.berry_calculator(num_bands=num_bands, geometry=geometry)
        return calculator.calculate(k_point, step=step, band_index=band_index)

    def compute_berry_grid(self, pattern, k_points, step, num_bands, band_index=None):
        """Calculate Berry curvature at arbitrary ``(N, 2)`` Cartesian k-points.

        Returns ``bcs`` with shape ``(N, num_bands)`` when ``band_index=None``,
        or ``(N,)`` for one 0-based band.
        """
        k_points = np.asarray(k_points, dtype=float)
        if k_points.ndim != 2 or k_points.shape[1] != 2:
            raise ValueError("k_points must have shape (N, 2).")
        if band_index is not None and (band_index < 0 or band_index >= num_bands):
            raise ValueError(f"band_index must be between 0 and {num_bands - 1}")

        geometry = self.convert_ndarray_to_meep_geo(pattern, rectify=True)
        calculator = self.berry_calculator(num_bands=num_bands, geometry=geometry)
        if band_index is None:
            values = np.zeros((len(k_points), num_bands), dtype=float)
        else:
            values = np.zeros(len(k_points), dtype=float)

        for idx, k_point in enumerate(k_points):
            values[idx] = calculator.calculate(k_point, step=step, band_index=band_index)

        return {
            "k_points": k_points,
            "bcs": values,
            "step": float(step),
            "num_bands": int(num_bands),
            "band_index": band_index,
            "lattice_type": self.lattice_type,
            "k_coordinate": "cartesian_reciprocal",
        }

    def _run_cartesian_k_frequencies(self, geometry, k_point, num_bands):
        reciprocal_k = mp.cartesian_to_reciprocal(mp.Vector3(float(k_point[0]), float(k_point[1]), 0), self.geo_latt)
        ms = mpb.ModeSolver(
            geometry_lattice=self.geo_latt,
            geometry=geometry,
            default_material=mp.air,
            resolution=self.resolution,
            num_bands=num_bands,
            k_points=[reciprocal_k],
            verbose=False,
        )
        ms.run_parity(mp.TE, False, mpb.fix_efield_phase)
        return np.asarray(ms.freqs[:num_bands], dtype=float)

    def compute_band_path_with_berry(
        self,
        pattern,
        path: HighSymmetryPath | None = None,
        n_per_segment: int = 10,
        step: float = 0.0005,
        num_bands: int = 3,
        compute_bc: bool = True,
    ):
        """Calculate frequencies and optional Berry color data along a path.

        ``n_per_segment`` is intervals per path segment. ``compute_bc=False``
        skips all field/plaquette work and returns ``bcs=None``. At exact
        high-symmetry vertices, only the Berry plaquette anchor is offset;
        frequency remains evaluated at the original path point.
        """
        if path is None:
            path = self.default_path()

        k_points, distances, tick_indices, tick_positions = path.interpolate(n_per_segment=n_per_segment)
        feature_geometry = self.convert_ndarray_to_meep_geo(pattern, rectify=True)
        geometry = self.create_material_block() + feature_geometry
        freqs = np.zeros((len(k_points), num_bands), dtype=float)
        bcs = np.zeros_like(freqs) if compute_bc else None
        calculator = self.berry_calculator(num_bands=num_bands, geometry=feature_geometry) if compute_bc else None

        for idx, k_point in enumerate(k_points):
            freqs[idx] = self._run_cartesian_k_frequencies(geometry, k_point, num_bands)
            if compute_bc:
                bc_anchor = path.offset_high_symmetry_point(k_point, step=step)
                bcs[idx] = np.asarray(calculator.calculate(bc_anchor, step=step), dtype=float)

        return {
            "k_points": k_points,
            "distances": distances,
            "tick_indices": tick_indices,
            "tick_positions": tick_positions,
            "labels": path.labels,
            "freqs": freqs,
            "actual_freqs": np.asarray(self.calculate_actual_freqs(freqs), dtype=float),
            "bcs": bcs,
            "step": float(step),
            "n_per_segment": int(n_per_segment),
            "lattice_type": self.lattice_type,
        }

    def compute_efs(self, pattern, k_points, num_bands=3):
        """Calculate normalized and THz frequencies at arbitrary k-points."""
        k_points = np.asarray(k_points, dtype=float)
        if k_points.ndim != 2 or k_points.shape[1] != 2:
            raise ValueError("k_points must have shape (N, 2).")
        feature_geometry = self.convert_ndarray_to_meep_geo(pattern, rectify=True)
        geometry = self.create_material_block() + feature_geometry
        freqs = np.zeros((len(k_points), num_bands), dtype=float)
        for idx, k_point in enumerate(k_points):
            freqs[idx] = self._run_cartesian_k_frequencies(geometry, k_point, num_bands)
        return EFSResult(
            k_points=k_points,
            freqs=freqs,
            actual_freqs=np.asarray(self.calculate_actual_freqs(freqs), dtype=float),
            metadata={
                "a": self.a,
                "resolution": self.resolution,
                "num_bands": num_bands,
                "k_coordinate": "cartesian_reciprocal",
                "lattice_type": self.lattice_type,
            },
        )

    def compute_triangular_efs(self, pattern, N, shrinking=0.01, num_bands=3):
        """Calculate EFS data on the legacy triangular C3-reduced mini-space."""
        k_points = np.asarray(triangular_reduced_zone_points(N=N, shrinking=shrinking), dtype=float)
        if len(k_points) == 0:
            raise ValueError("triangular_reduced_zone_points returned no k-points; increase N or reduce shrinking.")
        result = self.compute_efs(pattern, k_points, num_bands=num_bands)
        result.metadata.update({"grid": "triangular_reduced_zone", "N": N, "shrinking": shrinking})
        return result

    def compute_square_efs(self, pattern, N, extent=0.5, num_bands=3):
        """Calculate EFS data on an ``N x N`` square over ``[-extent, extent]^2``."""
        k_points = np.asarray(square_full_zone_points(N=N, extent=extent), dtype=float)
        result = self.compute_efs(pattern, k_points, num_bands=num_bands)
        result.metadata.update({"grid": "square_full_zone", "N": N, "extent": extent})
        return result

    def plot_efs(self, result: EFSResult, band_index=0, **kwargs):
        return plot_efs(result, band_index=band_index, **kwargs)

    def plot_band_path(self, result: dict, **kwargs):
        return plot_band_path(result, **kwargs)

    def plot_berry_grid(self, result: dict, band_index=0, **kwargs):
        """Plot one 0-based band from a Berry-grid result."""
        bcs = np.asarray(result["bcs"], dtype=float)
        if bcs.ndim == 2:
            if band_index < 0 or band_index >= bcs.shape[1]:
                raise ValueError(f"band_index must be between 0 and {bcs.shape[1] - 1}")
            values = bcs[:, band_index]
        else:
            values = bcs
        title = kwargs.pop("title", f"Berry curvature (Band {band_index + 1})")
        return plot_scalar_field(
            result["k_points"],
            values,
            title=title,
            colorbar_label="Berry curvature",
            **kwargs,
        )
