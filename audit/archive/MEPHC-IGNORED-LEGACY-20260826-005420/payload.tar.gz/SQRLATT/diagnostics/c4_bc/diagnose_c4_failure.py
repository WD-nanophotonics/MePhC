from __future__ import annotations

from pathlib import Path
import sys

import numpy as np
import meep as mp
from meep import mpb

case_root = Path(__file__).resolve().parents[2] / "square_hole"
project_root = case_root.parent
mephc_root = Path("/home/icy/MePhC")
for path in (project_root, case_root, mephc_root):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import config


def c4_orbit(k_point):
    kx, ky = map(float, k_point)
    return np.asarray([(kx, ky), (-ky, kx), (-kx, -ky), (ky, -kx)], dtype=float)


def rotate_vec(vec, quarter_turns):
    x, y = map(float, vec)
    quarter_turns %= 4
    if quarter_turns == 0:
        return np.array([x, y], dtype=float)
    if quarter_turns == 1:
        return np.array([-y, x], dtype=float)
    if quarter_turns == 2:
        return np.array([-x, -y], dtype=float)
    return np.array([y, -x], dtype=float)


def plaquette_points(k_point, step, mode="lower_left", quarter_turns=0):
    k = np.asarray(k_point, dtype=float)
    if mode == "lower_left":
        dx = np.array([step, 0.0])
        dy = np.array([0.0, step])
        origin = k
    elif mode == "centered":
        dx = np.array([step, 0.0])
        dy = np.array([0.0, step])
        origin = k - 0.5 * dx - 0.5 * dy
    elif mode == "rotated_basis":
        dx = rotate_vec((step, 0.0), quarter_turns)
        dy = rotate_vec((0.0, step), quarter_turns)
        origin = k
    elif mode == "centered_rotated_basis":
        dx = rotate_vec((step, 0.0), quarter_turns)
        dy = rotate_vec((0.0, step), quarter_turns)
        origin = k - 0.5 * dx - 0.5 * dy
    else:
        raise ValueError(f"Unknown plaquette mode: {mode}")
    return np.asarray([origin, origin + dx, origin + dx + dy, origin + dy], dtype=float)


class DiagnosticBC:
    def __init__(self, *, resolution, num_bands, run_band_func=mpb.fix_efield_phase):
        self.resolution = int(resolution)
        self.num_bands = int(num_bands)
        self.run_band_func = run_band_func
        self.band = config.make_band(resolution=resolution)
        feature_geometry = self.band.convert_ndarray_to_meep_geo(config.build_pattern(), rectify=True)
        self.geometry = self.band.create_material_block() + feature_geometry
        self.lattice = self.band.geo_latt

    def reciprocal(self, k_point):
        return mp.cartesian_to_reciprocal(mp.Vector3(float(k_point[0]), float(k_point[1]), 0), self.lattice)

    def solver(self, k_point):
        return mpb.ModeSolver(
            geometry=self.geometry,
            geometry_lattice=self.lattice,
            k_points=[self.reciprocal(k_point)],
            resolution=self.resolution,
            num_bands=self.num_bands,
            default_material=mp.air,
            verbose=False,
        )

    def run_solver(self, ms):
        if self.run_band_func is None:
            ms.run_parity(mp.TE, False)
        else:
            ms.run_parity(mp.TE, False, self.run_band_func)

    def reshape_field(self, field):
        arr = np.asarray(field)
        if arr.size == self.resolution * self.resolution * 3:
            return arr.reshape(self.resolution, self.resolution, 3)
        if arr.ndim == 4 and arr.shape[-1] == 3 and arr.shape[2] == 1:
            return arr[:, :, 0, :]
        if arr.ndim == 3 and arr.shape[-1] == 3:
            return arr
        raise ValueError(f"Unexpected field shape {arr.shape}")

    def reshape_eps(self, eps):
        arr = np.asarray(eps)
        if arr.size == self.resolution * self.resolution:
            return arr.reshape(self.resolution, self.resolution)
        if arr.ndim == 3 and arr.shape[2] == 1:
            return arr[:, :, 0]
        if arr.ndim == 2:
            return arr
        raise ValueError(f"Unexpected epsilon shape {arr.shape}")

    def fields_at(self, k_point):
        ms = self.solver(k_point)
        self.run_solver(ms)
        e_fields = []
        h_fields = []
        for band_index in range(1, self.num_bands + 1):
            e_fields.append(self.reshape_field(ms.get_efield(band_index, bloch_phase=False)))
            h_fields.append(self.reshape_field(ms.get_hfield(band_index, bloch_phase=False)))
        eps = self.reshape_eps(ms.get_epsilon())
        freqs = np.asarray(ms.freqs[: self.num_bands], dtype=float)
        return np.asarray(e_fields), np.asarray(h_fields), eps, freqs

    def normalize(self, e_fields, h_fields, eps):
        eps4 = eps.reshape(1, self.resolution, self.resolution, 1)
        energy = np.sum(eps4 * np.conj(e_fields) * e_fields, axis=(1, 2, 3))
        energy += np.sum(np.conj(h_fields) * h_fields, axis=(1, 2, 3))
        norm = np.sqrt(np.real(energy))
        return e_fields / norm[:, None, None, None], h_fields / norm[:, None, None, None]

    def overlap(self, e1, h1, e2, h2, eps):
        eps4 = eps.reshape(1, self.resolution, self.resolution, 1)
        value = np.sum(eps4 * np.conj(e1) * e2, axis=(1, 2, 3))
        value += np.sum(np.conj(h1) * h2, axis=(1, 2, 3))
        mag = np.abs(value)
        return value / mag, mag

    def calculate_plaquette(self, points, step):
        fields = []
        freqs = []
        for point in points:
            e, h, eps, f = self.fields_at(point)
            e, h = self.normalize(e, h, eps)
            fields.append((e, h, eps))
            freqs.append(f)
        freqs = np.asarray(freqs, dtype=float)
        values = []
        min_link_mags = []
        for band_idx in range(self.num_bands):
            links = []
            mags = []
            for i in range(4):
                e1, h1, eps1 = fields[i]
                e2, h2, _ = fields[(i + 1) % 4]
                link, mag = self.overlap(
                    e1[band_idx : band_idx + 1],
                    h1[band_idx : band_idx + 1],
                    e2[band_idx : band_idx + 1],
                    h2[band_idx : band_idx + 1],
                    eps1,
                )
                links.append(link)
                mags.append(float(mag[0]))
            flux = np.angle(links[0] * links[1] * links[2] * links[3])
            value = float(np.real(flux[0] / (step * step) / (2 * np.pi) ** 2))
            values.append(value)
            min_link_mags.append(min(mags))
        return {"bc": np.asarray(values), "freqs": freqs, "min_link_mags": np.asarray(min_link_mags)}


def gaps(freqs):
    if freqs.shape[-1] < 2:
        return np.empty(freqs.shape[:-1] + (0,))
    return np.diff(freqs, axis=-1)


def summarize_orbit(name, rows):
    values = np.asarray([row["bc"] for row in rows], dtype=float)
    means = values.mean(axis=0)
    max_dev = np.max(np.abs(values - means), axis=0)
    denom = np.maximum(np.abs(means), 1e-12)
    rel = max_dev / denom
    print(f"\n{name}")
    for idx, row in enumerate(rows):
        freqs0 = row["freqs"][0]
        gap0 = gaps(row["freqs"])[0]
        print(
            f"  orbit {idx}: k={tuple(row['k'])} bc={row['bc'].tolist()} "
            f"freq0={freqs0.tolist()} gaps0={gap0.tolist()} min_links={row['min_link_mags'].tolist()}"
        )
    for band_idx in range(values.shape[1]):
        print(
            f"  band {band_idx + 1}: mean={means[band_idx]:.8g}, "
            f"max_dev={max_dev[band_idx]:.8g}, rel_dev={rel[band_idx]:.8g}"
        )
    return {"values": values, "mean": means, "max_dev": max_dev, "rel_dev": rel}


def run_modes(k_point=(0.2, 0.1), resolution=8, num_bands=3, step=0.01, run_band_func=mpb.fix_efield_phase):
    calc = DiagnosticBC(resolution=resolution, num_bands=num_bands, run_band_func=run_band_func)
    orbit = c4_orbit(k_point)
    summaries = {}
    for mode in ("lower_left", "centered", "rotated_basis", "centered_rotated_basis"):
        rows = []
        for quarter_turns, point in enumerate(orbit):
            points = plaquette_points(point, step, mode=mode, quarter_turns=quarter_turns)
            result = calc.calculate_plaquette(points, step)
            result.update({"k": point, "plaquette": points})
            rows.append(result)
        summaries[mode] = summarize_orbit(mode, rows)
    return summaries


def repeatability(k_point=(0.2, 0.1), resolution=8, num_bands=3, step=0.01, repeats=3):
    print("\nrepeatability")
    for run_band_func, label in ((mpb.fix_efield_phase, "fix_efield_phase"), (None, "none")):
        vals = []
        for _ in range(repeats):
            calc = DiagnosticBC(resolution=resolution, num_bands=num_bands, run_band_func=run_band_func)
            points = plaquette_points(k_point, step, mode="centered")
            vals.append(calc.calculate_plaquette(points, step)["bc"])
        vals = np.asarray(vals)
        print(f"  {label}: values={vals.tolist()} max_span={(vals.max(axis=0) - vals.min(axis=0)).tolist()}")


def scan_resolution_step(k_point=(0.2, 0.1), resolutions=(4, 8, 16), steps=(0.02, 0.01, 0.005), num_bands=1):
    print("\nresolution/step scan using centered_rotated_basis")
    for resolution in resolutions:
        for step in steps:
            summaries = run_modes(k_point=k_point, resolution=resolution, num_bands=num_bands, step=step)
            max_dev = summaries["centered_rotated_basis"]["max_dev"].tolist()
            print(f"  resolution={resolution} step={step}: max_dev={max_dev}")


def main():
    print("C4 failure diagnostic")
    print("case:", case_root)
    print("default k=(0.2, 0.1), resolution=8, num_bands=3, step=0.01")
    run_modes()
    repeatability()
    scan_resolution_step(num_bands=1)


if __name__ == "__main__":
    main()