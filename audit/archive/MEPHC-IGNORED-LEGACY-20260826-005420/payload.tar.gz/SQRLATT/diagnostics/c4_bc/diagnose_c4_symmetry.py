from pathlib import Path
import sys

import numpy as np

case_root = Path(__file__).resolve().parents[2] / "square_hole"
project_root = case_root.parent
mephc_root = Path("/home/icy/MePhC")
for path in (project_root, case_root, mephc_root):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import config


def c4_orbit(k_point):
    kx, ky = map(float, k_point)
    return np.asarray(
        [
            (kx, ky),
            (-ky, kx),
            (-kx, -ky),
            (ky, -kx),
        ],
        dtype=float,
    )


def diagnose(k_point=(0.25, 0.1), resolution=8, num_bands=3, step=0.01):
    from mephc.band import Band

    band = config.make_band(resolution=resolution)
    pattern = config.build_pattern()
    points = c4_orbit(k_point)
    values = []
    for point in points:
        values.append(band.calculate_berry_curvature(pattern, point, step=step, num_bands=num_bands))
    values = np.asarray(values, dtype=float)
    means = values.mean(axis=0)
    deviations = np.max(np.abs(values - means), axis=0)
    denom = np.maximum(np.abs(means), 1e-12)
    relative = deviations / denom

    print("C4 Berry curvature diagnostic")
    print("case:", case_root)
    print("k orbit:")
    for point, value in zip(points, values):
        print(f"  k={tuple(point)} values={value.tolist()}")
    print("band summary:")
    for idx in range(num_bands):
        print(
            f"  band {idx + 1}: mean={means[idx]:.8g}, "
            f"max_dev={deviations[idx]:.8g}, rel_dev={relative[idx]:.8g}"
        )
    return {"points": points, "values": values, "mean": means, "max_deviation": deviations, "relative_deviation": relative}


if __name__ == "__main__":
    diagnose()