# AgentRelay Phase 2 — Silent Background & Token-Safety Contract

This document is **normative** for Phase 2. If it conflicts with a convenience-oriented implementation choice, this contract wins.

## 1. Core rule

> AgentRelay may work in the background, but it may not unexpectedly take over the user's desktop.

A functional success that steals foreground focus is not certified for unattended operation.

## 2. Human-visible UI contract

### Allowed

- The user explicitly launches/opens the AgentRelay UI.
- The user explicitly clicks a diagnostic button that clearly indicates it may show another application.
- An already-visible AgentRelay UI updates labels/status without changing Z-order or focus.

### Forbidden during automatic background events

- create/show Tk root because Gmail arrived;
- `focus_force`, automatic `lift`, topmost toggling, activation, or equivalent;
- modal message box for Gmail/wake/error/HUMAN_REQUIRED;
- taskbar/foreground activation intended to demand attention;
- opening a visible console for status/error output.

`HUMAN_REQUIRED` means **stop safely and record state**, not **interrupt the desktop**.

## 3. Console/helper process contract

Automatic supervisor and wake paths must create:

```text
visible CMD windows = 0
visible PowerShell windows = 0
visible Python console windows = 0
```

If a subprocess is required on Windows, use an actually hidden/no-console execution path appropriate to the executable and preserve stdout/stderr through pipes/files rather than a console window.

Do not rely only on `shell=False` as proof that no console can appear.

The rule applies recursively to helper processes launched by AgentRelay.

## 4. Foreground contract

For background certification, choose an unrelated foreground application before the automated action.

During:

- Gmail polling;
- Gmail staging;
- protocol validation;
- wake authorization;
- real Codex wake;
- worker status updates;
- errors and HUMAN_REQUIRED transitions;

AgentRelay must not cause an unexpected foreground-owner change.

Capture objective evidence with Windows APIs or another reliable local mechanism where practical.

A change caused by the human manually clicking another window is not a failure; a change initiated by AgentRelay/helper automation is.

## 5. Codex wake contract

Preferred wake paths are programmatic thread/session APIs that do not require foreground activation.

Do not click/focus the Codex desktop window to wake an agent if an official programmatic path can address the intended thread/session.

A real wake must target exactly one bound agent.

One validated Gmail message → at most one real wake.

Wake API accepted → `AGENT_RUNNING`, **not** immediate lease completion.

## 6. Chrome/ChatGPT contract

Browser handoff has two independent certification dimensions:

```text
FUNCTIONAL
SILENT_BACKGROUND
```

Possible result:

```text
FUNCTIONAL_PASS
SILENT_BACKGROUND_FAIL
```

This means the browser capability may be retained for explicit/manual diagnostic use, but it is **not approved for unattended automatic handoff**.

The configured ChatGPT conversation URL is exact. The agent must not search conversation history or browse around to guess the target.

Automatic retry budget per lease should remain tiny:

```text
navigation attempts <= 2
send attempts <= 1
reload attempts <= 1
```

Do not poll the ChatGPT page for a response after sending.

## 7. Token-safety contract

### Ordinary software may wait

The Gmail poller may run every ~10–20 seconds without any model invocation.

### AI may not wait

Codex must not remain active merely because it is waiting for:

- Gmail;
- ChatGPT;
- user approval;
- an external reply.

At such a boundary the Codex turn yields/stops.

### No mechanical LLM loops

Forbidden patterns:

```text
wake model → no mail → sleep → wake model → no mail
```

```text
send ChatGPT report → ask model to check whether reply arrived → repeat
```

```text
browser failed → start new Codex turn → retry indefinitely
```

## 8. Retry/failure contract

Retries are controlled by ordinary deterministic software, not by recursive model turns.

Wake failures must have a strict bound.

Ambiguous wake state after crash/restart must fail closed instead of blindly invoking the same lease again.

Browser failure must converge to a stable state such as:

```text
HUMAN_REQUIRED
HANDOFF_FAILED
CHAT_HANDOFF_NOT_SILENT_CERTIFIED
```

No automatic infinite recovery.

## 9. Persistence and recovery contract

Persist enough state before irreversible side effects to ensure restart safety.

The program must be able to distinguish, as far as deterministic evidence permits:

```text
mail seen
mail staged
lease authorized
wake attempted
wake accepted
agent running
completion received
handoff completed
waiting for next reply
```

If process death leaves the exact wake outcome unknowable, prefer `RECOVERY_REQUIRED/HUMAN_REQUIRED` over a duplicate wake.

## 10. Start/Stop contract

Default on process/UI launch:

```text
STOPPED
```

Only explicit human Start enables active Gmail monitoring/wake behavior.

Explicit Stop must prevent new:

- Gmail workflow processing;
- staging;
- lease creation;
- Codex wake;
- browser handoff initiation.

Stop must not itself create a visible console or steal foreground.

## 11. Required silent-background certification

A certification run should exercise:

1. supervisor/UI startup by explicit human action;
2. multiple Gmail polling cycles;
3. valid-message staging;
4. one real wake attempt;
5. error/HUMAN_REQUIRED path;
6. stop;
7. if supported, one browser handoff diagnostic.

Record:

```text
foreground events attributable to AgentRelay
visible console/helper windows
unexpected UI activations
wake target identity
process IDs
result status
```

Minimum unattended gates:

```text
unexpected AgentRelay foreground activations = 0
visible console windows created by AgentRelay path = 0
unexpected AgentRelay UI raises = 0
```

Browser handoff receives its own independent silent-background gate.

## 12. Certification labels

Use precise labels rather than vague statements such as "seems silent".

Examples:

```text
SILENT_POLLING_PASS
SILENT_REAL_WAKE_PASS
CHAT_HANDOFF_FUNCTIONAL_PASS
CHAT_HANDOFF_SILENT_PASS
```

or

```text
SILENT_REAL_WAKE_FAIL
CHAT_HANDOFF_NOT_SILENT_CERTIFIED
```

## 13. Final invariant

The intended steady-state architecture is:

```text
Supervisor: always allowed to wait, zero LLM tokens
Codex: awake only with one validated lease
ChatGPT: audits only when handed a completed report
Gmail: durable asynchronous transport
Human: observes and intervenes only when desired or HUMAN_REQUIRED
```

The background system must remain quiet enough that the user can continue ordinary Windows work without AgentRelay, its shells, its UI, Codex, or its helper processes unexpectedly jumping to the foreground.

