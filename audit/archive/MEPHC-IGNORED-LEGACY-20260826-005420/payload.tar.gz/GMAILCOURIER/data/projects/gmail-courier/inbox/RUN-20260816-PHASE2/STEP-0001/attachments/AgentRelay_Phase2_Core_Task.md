# AgentRelay Read & Wake — Phase 2
## Real Gmail → Codex wake, bounded work lease, silent background operation, and controlled ChatGPT handoff

**Authoritative task for:** `WD-nanophotonics/agent-relay-read-wake`

**Expected baseline:** `main` at `d8090f944b88cb09addbc8347b817bde81da3976` (`Add AgentRelay read and wake supervisor`)

**Protocol transaction:**

- CHANNEL: `AR-GMAILCOURIER-A1R7P`
- RUN: `RUN-20260816-PHASE2`
- STEP: `0001`
- PARENT: `0000`

This is Phase 2. Inspect the actual repository and local environment before changing code. Verify the baseline locally and against `origin/main`. If the repository is not at the expected baseline, do not silently rebase or overwrite unrelated work; report the mismatch and preserve all unrelated state.

---

# 1. Phase 2 objective

Phase 1 established a deterministic Gmail protocol, staging, persistent state, audit ledger, UI, `CodexTarget`, `WakeAdapter`, and a mock wake path.

Phase 2 must make the first half of the real autonomous loop work:

```text
human explicitly starts Supervisor
        ↓
Supervisor polls Gmail using ordinary code only
        ↓
valid AGENTRELAY/1 WAKE message appears
        ↓
message + attachments staged atomically
        ↓
strict deterministic wake gate passes
        ↓
Supervisor wakes exactly ONE already-bound real Codex agent/thread
        ↓
Codex reads staged authoritative instruction
        ↓
Codex performs ONE bounded work lease
        ↓
Codex tests work
        ↓
Codex pushes applicable changes to Git remote
        ↓
Codex uses the configured Chrome/ChatGPT handoff path if certified safe
        ↓
Codex submits its complete report to the fixed project ChatGPT conversation
        ↓
Codex terminates/yields; it does NOT wait for ChatGPT and does NOT poll Gmail
        ↓
Supervisor alone waits for the next Gmail instruction
```

The architectural principle remains:

> **AI never waits. Software waits.**

A second principle is now equally mandatory:

> **Background automation never steals the human desktop.**

Phase 2 is not complete merely because the functional chain works. Silent/background behavior is a hard certification gate.

---

# 2. Start by auditing Phase 1, not rewriting it

Before implementation:

1. inspect the current `WakeAdapter`, `CodexTarget`, supervisor state machine, UI, Gmail gateway, protocol, storage, tests, and README;
2. run the complete existing test suite;
3. verify `origin/main` and local HEAD;
4. identify the smallest compatible extension path;
5. preserve Phase 1 protocol and safety invariants unless a concrete defect requires a change.

Do not replace the deterministic protocol with a new agent framework.
Do not introduce an LLM router.
Do not make Codex poll Gmail.
Do not introduce Go mode.
Do not add broad Windows GUI automation as the primary control mechanism.

---

# 3. Mandatory architecture correction: wake acceptance is NOT lease completion

The Phase 1 mock implementation is allowed to treat a mock call as immediately complete. A real Codex wake cannot.

For the real adapter, distinguish at least:

```text
READY_TO_WAKE
    ↓
WAKING
    ↓ real wake accepted
AGENT_RUNNING
    ↓ deterministic completion/handoff evidence
WAITING_FOR_REPLY
```

A successful API call that starts/resumes a Codex turn means only:

```text
WAKE_ACCEPTED
```

It does **not** mean:

```text
LEASE_COMPLETED
```

The active lease must remain active while the real Codex work turn is running.

Design a deterministic lifecycle with clear evidence for:

- wake accepted;
- agent/turn running;
- agent/turn completed;
- ChatGPT handoff succeeded or was not safely available;
- lease completed;
- lease failed/suspended.

Do not infer these states from vague natural-language model output if a programmatic event, return status, structured local completion record, or explicit local callback can be used instead.

A simple local lease-completion mechanism is acceptable, for example a supervisor API/IPC/CLI command or atomic completion record keyed by `lease_id`, provided it cannot accidentally complete the wrong lease and it does not require a visible shell window.

Keep the design small.

---

# 4. Real Codex target binding

Phase 2 must replace the production `mock` target with a real, explicit target-binding path while retaining the mock adapter for tests.

The user must be able to bind the supervisor to exactly one real Codex agent/thread/session.

Authoritative identity should be something stable such as:

```text
target_type
thread/session identifier
human-readable label
repository path
optional runtime metadata
```

A Windows HWND/window title may be displayed diagnostically but must NOT be the authoritative identity if a stable Codex thread/session identity is available.

Preferred implementation order:

1. official Codex App Server / SDK thread or turn interface, if it can address the intended existing agent and satisfies the required capabilities;
2. another official non-interactive Codex resume interface if necessary;
3. only as a narrow fallback, a subprocess-based Codex invocation, but it must be launched with no visible console and must preserve the intended session/thread semantics.

Do not simulate mouse clicks on the Codex UI merely to claim wake support.

## Required binding safety

Automatic wake is permitted only if:

- exactly one configured target is bound;
- the target can be validated/probed;
- its repository identity matches the configured project when applicable;
- no other active lease exists;
- the supervisor is explicitly in MONITORING state.

If target identity is ambiguous or unavailable:

```text
HUMAN_REQUIRED
```

Do not guess which Codex window/thread to use.

---

# 5. Capability spike before committing to the real-wake implementation

Before deeply integrating a specific Codex wake mechanism, run a narrow diagnostic spike.

Prove, with evidence:

### Spike A — real wake/resume

A local ordinary program can address/resume/start exactly the intended Codex thread/agent and cause one bounded test turn.

### Spike B — event/lifecycle observability

The supervisor can determine, programmatically where possible, whether the wake was accepted and when the corresponding turn has ended or failed.

### Spike C — Chrome capability from the chosen wake path

Determine whether a Codex turn created/resumed through the chosen programmatic path can actually use the user's configured Chrome/ChatGPT integration required for future handoff.

Do not assume this capability exists merely because desktop Codex can use Chrome in another context.

If Spike C fails, do NOT throw away the successful real wake path. Isolate browser handoff behind its own adapter/capability and report the precise boundary.

The architecture must allow:

```text
RealCodexWakeAdapter = PASS
ChromeChatHandoffAdapter = UNSUPPORTED / NOT YET CERTIFIED
```

without destabilizing Gmail → Codex wake.

---

# 6. Silent Background Contract — HARD REQUIREMENT

The detailed normative contract is attached separately as:

`AgentRelay_Phase2_Silent_Background_Contract.md`

Treat it as part of this task.

The most important rule is:

> A functional PASS does not override a silent-background FAIL.

During ordinary background monitoring and automatic wake, AgentRelay must not steal foreground focus from unrelated Windows applications.

This includes every helper process launched by AgentRelay.

Forbidden behavior includes, but is not limited to:

- CMD window flash;
- PowerShell window flash;
- Python console flash;
- helper shell becoming visible;
- AgentRelay UI automatically raising itself;
- AgentRelay UI calling `focus_force`, `lift`, `activate`, or equivalent because a background event occurred;
- an error dialog unexpectedly taking foreground;
- browser launcher stealing focus as a hidden side effect;
- repeatedly bringing Codex to the front merely because a wake occurred.

The UI may appear when the human explicitly opens/requests it.
A UI that the user has left open may update its labels/status in place, but background events must not raise or refocus it.

If a chosen browser/Chrome integration inherently requires foreground stealing and this cannot be prevented safely, do not silently certify it. Mark browser handoff as not silent-background-certified and fail closed for unattended use.

---

# 7. Worker/UI separation

Strengthen the Phase 1 architecture so background monitoring is not conceptually tied to a foreground Tk window.

The long-term target is:

```text
background supervisor/worker
    - no console
    - no visible helper window
    - no foreground activation
    - polls Gmail
    - stages messages
    - manages leases

optional UI/monitor
    - appears only on explicit human action
    - observes/controls worker
    - never self-raises on background events
```

Phase 2 does not require packaging two separate `.exe` files if that would be premature, but the code boundaries must support this separation cleanly.

Do not add Windows autostart yet unless it is required only for a diagnostic and remains disabled by default.

Explicit user Start/Stop semantics remain authoritative.

---

# 8. Gmail polling remains deterministic and token-free

Retain ordinary Gmail polling at a configurable interval (approximately 10–20 seconds is appropriate).

The poller may run indefinitely while MONITORING because it is ordinary code and consumes no model tokens.

It must never wake Codex merely to ask whether mail exists.

Preserve the existing deterministic envelope model:

```text
AGENTRELAY/1
CHANNEL: ...
RUN: ...
STEP: ...
PARENT: ...
DISPOSITION: ...
PROJECT: ...
```

Preserve duplicate, old-step, out-of-order, wrong-parent, conflicting-step, wrong-project/channel, and active-lease protections.

Do not silently jump to the newest message.

---

# 9. One Gmail message may cause at most one real wake

This is a hard invariant.

A valid Gmail message may create at most one lease and at most one automatic real-agent wake.

A process restart, UI reopen, duplicate Gmail result, repeated polling cycle, or delayed event must not invoke the same lease again.

If the process crashes after persisting a wake authorization but before durable wake outcome is known, do not blindly wake again on restart. Use a conservative recovery state such as:

```text
HUMAN_REQUIRED / RECOVERY_REQUIRED
```

unless there is deterministic evidence that retry is safe.

Duplicate suppression must survive restart.

---

# 10. Bounded lease contract delivered to Codex

Extend the wake prompt/template so a real awakened Codex agent receives an explicit bounded contract.

It must include, at minimum:

```text
AGENTRELAY_WAKE/1
Project: <project>
Run: <run>
Step: <step>
Lease: <lease_id>
Staged instruction: <absolute path>
```

And unambiguously instruct the agent:

1. read the staged authoritative Gmail instruction and attachments;
2. perform exactly one requested workflow step/phase;
3. operate only in the configured project/repository unless the instruction explicitly authorizes something else;
4. run relevant tests;
5. inspect its diff/status before completion;
6. push applicable repository changes to the configured Git remote;
7. verify the remote commit where practical;
8. coding/testing/pushing is NOT the final terminal condition;
9. after push, hand the complete final report to the fixed configured ChatGPT conversation using the certified Chrome/ChatGPT handoff capability;
10. after successful handoff, signal deterministic lease completion if the architecture requires it;
11. then terminate/yield the Codex turn;
12. never poll Gmail;
13. never wait for ChatGPT;
14. never begin another workflow step without a new supervisor wake;
15. never enter an autonomous idle/retry loop.

The wake prompt itself should remain concise. The long task content belongs in the staged Gmail attachment, not duplicated in the wake command.

---

# 11. Git push contract

For tasks that modify this repository, Codex should normally:

```text
work
→ test
→ inspect diff/status
→ commit intentionally
→ push configured branch
→ verify remote SHA
→ report
```

Do not treat a local-only commit as successful completion when push is expected.

However, the Supervisor itself does not need to become a GitHub auditor in Phase 2.

If Codex falsely reports completion without pushing, ChatGPT auditing the remote repository will detect the mismatch in the next review round. This is a safe failure mode.

Do not bloat the supervisor with semantic Git auditing unless a tiny deterministic check is clearly useful.

---

# 12. Controlled Chrome → ChatGPT handoff

Add/configure a fixed project ChatGPT target URL.

The agent should not search ChatGPT history, guess conversations, browse unrelated pages, or poll for a response.

The intended future flow is narrowly:

```text
use certified Chrome integration
→ navigate/focus the exact configured ChatGPT conversation
→ submit complete Codex completion report
→ verify send success if deterministically observable
→ terminate/yield
```

## Critical background rule

The Chrome/ChatGPT handoff must be separately tested for foreground stealing.

Do not assume successful browser control is acceptable if Chrome suddenly jumps in front of the user's active work.

For unattended certification:

```text
functional success + foreground steal = FAIL
```

If Chrome handoff cannot yet be made silent/background-safe:

- retain the handoff abstraction;
- preserve the exact chat target binding;
- fail closed or require an explicit human-triggered handoff;
- report `CHAT_HANDOFF_NOT_SILENT_CERTIFIED`;
- do not retry repeatedly;
- do not compromise the otherwise working Gmail → real Codex wake path.

## Browser retry budget

Keep automatic browser retries tiny and deterministic.

Recommended maximum during one lease:

```text
navigation attempts <= 2
send attempts <= 1
reload attempts <= 1
```

If the safe budget is exhausted:

```text
HUMAN_REQUIRED / HANDOFF_FAILED
```

No LLM retry loop.

---

# 13. No Go mode / no token-burning wait loops

Do not solve continuity by leaving Codex continuously running.

Forbidden:

```text
while True:
    ask Codex whether Gmail changed
```

Forbidden:

```text
Codex sends ChatGPT a report
then keeps checking browser/Gmail every few seconds
```

Forbidden:

```text
retry model turn until success
```

Allowed:

```text
Supervisor polls Gmail every N seconds using ordinary code
```

Allowed:

```text
Codex performs continuous local work inside one bounded lease while real progress exists
```

Mandatory yield point:

```text
WAIT_FOR_CHATGPT
WAIT_FOR_GMAIL
WAIT_FOR_USER
WAIT_FOR_EXTERNAL_RESPONSE
```

At those boundaries, the model must stop and ordinary software takes over waiting.

---

# 14. Timeouts and failure states

Do not convert a timeout into model polling.

Examples:

### Gmail unavailable

Record error/health state. Retry only on later normal software polling with bounded/backoff behavior.

### Codex wake rejected

No repeated model invocation. Record failure and enter a stable human/recovery state.

### Agent turn crashes

At most one deterministic recovery attempt if the API provides clear safe resumability; otherwise fail closed.

### ChatGPT handoff unavailable

Do not wake a second Codex turn merely to retry browser use. End/suspend the lease with explicit status.

### ChatGPT has not replied

This is normal waiting. Codex must already be stopped. Supervisor continues low-cost Gmail polling.

---

# 15. UI requirements for Phase 2

Retain the simple UI, but improve it enough to make the real target and runtime state auditable.

Display at least:

```text
Supervisor state
Monitoring ON/OFF
Project
Channel
Bound Codex target type
Bound Codex target ID/thread/session
Target validation status
Repo path
ChatGPT URL binding status
Current RUN / expected STEP
Active lease ID
Agent/turn state
Last Gmail poll
Last staged mail
Last wake attempt/result
Last agent completion
Last handoff status
Silent-background certification status
Last fault / HUMAN_REQUIRED reason
```

Useful controls:

```text
Start
Stop
Bind/Edit Project
Bind/Test Codex Target
Test Gmail
Test Real Wake (bounded diagnostic)
Test Chat Handoff (explicit human-triggered diagnostic)
Open Inbox
Open Logs
```

A diagnostic button may intentionally cause visible UI/browser activity only when the human explicitly clicks it and the UI clearly says so. Such a diagnostic does NOT certify unattended silent behavior.

Background events must never automatically pop an error dialog or raise the window.

---

# 16. Silent-background instrumentation

Implement or create a certification harness capable of collecting evidence on Windows.

At minimum, measure or observe:

```text
foreground window before test
foreground window throughout test if practical
foreground window after test
visible console windows attributable to AgentRelay/helper processes
unexpected AgentRelay UI activation
unexpected helper-window activation
process IDs spawned during wake
```

Avoid brittle heuristics when a direct Windows API observation is practical.

The certification must be runnable without requiring the human to watch carefully and report subjective impressions.

Do not create a monitor that itself steals foreground.

---

# 17. Required tests

Keep all Phase 1 tests passing.

Add focused tests for at least:

1. real adapter configuration parsing;
2. exactly-one-target binding invariant;
3. real wake accepted does not immediately equal lease completed;
4. active lease persists through AGENT_RUNNING;
5. deterministic completion transitions to WAITING_FOR_REPLY;
6. wake failure produces stable fail-closed state;
7. restart with ambiguous in-flight lease does not double-wake;
8. same Gmail ID cannot cause two real wake attempts;
9. same logical step cannot cause two real leases;
10. Stop blocks real wake;
11. Gmail polling itself invokes no Codex/model path;
12. wake template contains bounded lease/end-of-lease rules;
13. helper subprocess launch flags are no-console on Windows if subprocess fallback exists;
14. background event cannot call UI-raise/focus code;
15. chat target must be exact/configured, never guessed;
16. handoff retry budget is bounded;
17. malformed/ambiguous target → HUMAN_REQUIRED;
18. existing protocol/storage isolation regressions remain green.

Where OS-level focus behavior cannot be unit-tested reliably, provide an integration certification harness and saved evidence.

---

# 18. Required integration certifications

Run real local integration tests where the environment permits.

## Certification A — Phase 1 regression

All previous tests and invariants pass.

## Certification B — silent polling

1. Put an unrelated application in foreground.
2. Start monitoring by explicit user action.
3. Run multiple polling cycles.
4. No console/helper/UI window steals foreground.

Expected:

```text
SILENT_POLLING_PASS
```

## Certification C — Gmail → staged instruction

Use a valid AGENTRELAY fixture or safe real Gmail message.

Expected:

```text
one match
one stage
one lease authorization
no duplicate processing
```

## Certification D — real Codex wake

Use a bounded harmless diagnostic task against the explicitly bound target.

Expected:

```text
exactly one wake
correct target
no visible console
no foreground steal
wake accepted != immediate lease completion
agent completion observed deterministically
```

If fully successful:

```text
REAL_WAKE_PASS
SILENT_REAL_WAKE_PASS
```

## Certification E — restart/double-wake safety

Simulate/reproduce a restart around a persisted in-flight lease.

Expected:

```text
no accidental second wake
```

## Certification F — ChatGPT handoff capability

Test the chosen Codex wake path against the configured Chrome/ChatGPT capability.

Classify separately:

```text
CHAT_HANDOFF_FUNCTIONAL_PASS | CHAT_HANDOFF_UNAVAILABLE
```

and

```text
CHAT_HANDOFF_SILENT_PASS | CHAT_HANDOFF_NOT_SILENT_CERTIFIED
```

Do not merge these two questions.

---

# 19. Git and repository requirements

You are authorized to modify this new repository and push the Phase 2 work.

Required completion sequence:

1. verify baseline;
2. implement only the Phase 2 scope;
3. run focused tests;
4. run full pytest;
5. run integration certifications that are safe and possible locally;
6. inspect final diff;
7. verify secrets/runtime Gmail data are not tracked;
8. commit intentionally;
9. push `main` (or the already-configured intended branch if repository state proves otherwise);
10. verify remote HEAD matches the intended commit.

Do not delete unrelated work.
Do not force-push.
Do not rewrite public history.
Do not commit OAuth credentials, Gmail contents, logs, runtime state, or local ChatGPT identifiers that should remain local.

---

# 20. Mandatory end-of-phase behavior

After code/test/push, produce a complete report containing:

1. baseline local + remote SHA;
2. final local + remote SHA;
3. files changed;
4. wake mechanism selected and why;
5. exact Codex target identity model;
6. real wake lifecycle and how lease completion is represented;
7. Gmail → wake flow;
8. restart/double-wake behavior;
9. UI/worker separation changes;
10. silent-background implementation;
11. silent-background certification evidence;
12. exact visible-window/foreground results;
13. real wake diagnostic result;
14. Chrome/ChatGPT capability result;
15. Chrome/ChatGPT silent-background result;
16. tests and exact counts;
17. Git push verification;
18. known limitations/blockers;
19. what remains for Phase 3/full closed loop.

Then, **if and only if the configured ChatGPT handoff path is both functional and certified safe enough for this run**, use it to submit the complete report to the fixed project ChatGPT conversation.

After successful report handoff:

```text
STOP THE CODEX TURN
```

Do not wait for a reply.
Do not open Gmail to see whether ChatGPT has replied.
Do not start Phase 3.
Do not enter Go mode.

If ChatGPT handoff is not available or not silent-certified, report that fact in the normal Codex completion output and stop. Do not repeatedly retry.

---

# 21. Phase 2 terminal statuses

Use one of these top-level outcomes:

```text
PHASE2_FULL_PASS
```

Meaning:

- real Gmail → Codex wake works;
- bounded lease lifecycle works;
- no double-wake path found;
- silent polling passes;
- silent real wake passes;
- repository changes pushed and verified;
- ChatGPT handoff is functional and silent-certified for unattended use.

or:

```text
PHASE2_WAKE_PASS_HANDOFF_PENDING
```

Meaning:

- Gmail → real Codex wake and lease lifecycle are correct and silent;
- repository pushed;
- browser/ChatGPT handoff remains unavailable or not silent-certified.

or:

```text
PHASE2_BLOCKED
```

with concrete evidence showing the blocking boundary.

Do not blur a browser limitation into a failure of the already-correct Gmail/wake core, and do not claim `FULL_PASS` if silent-background requirements fail.

