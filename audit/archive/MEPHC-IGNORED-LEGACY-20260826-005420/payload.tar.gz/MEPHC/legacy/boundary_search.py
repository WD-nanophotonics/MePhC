import numpy as np
from data_handler import *

# Assuming the previous function is already defined
def find_boundary_for_N2_array(array, direction):

    if direction == "left":
        return np.min(array[:, 0])
    elif direction == "right":
        return np.max(array[:, 0])
    elif direction == "top":
        return np.max(array[:, 1])
    elif direction == "bottom":
        return np.min(array[:, 1])
    else:
        raise ValueError("Invalid direction. Choose among ['left', 'right', 'top', 'bottom'].")


def find_boundary_for_points(data, direction):
    data=convert_to_one_layer_pattern_list(data)
    # Initialize a variable to store the final boundary value
    if direction in ["left", "bottom"]:
        # Initialize with a very large value for left and bottom
        boundary_value = float('inf')
    elif direction in ["right", "top"]:
        # Initialize with a very small value for right and top
        boundary_value = -float('inf')
    else:
        raise ValueError("Invalid direction. Choose among ['left', 'right', 'top', 'bottom'].")

    # Iterate through each array in the list
    for array in data:
        # Find the boundary for the current array
        current_boundary = find_boundary_for_N2_array(array, direction)

        # Update the final boundary value based on the direction
        if direction in ["left", "bottom"]:
            boundary_value = min(boundary_value, current_boundary)
        elif direction in ["right", "top"]:
            boundary_value = max(boundary_value, current_boundary)

    return boundary_value




if __name__=="__main__":
    # Example usage:
    points_list = [
        np.array([[1, 2], [3, 4], [5, 0], [7, 8]]),
        np.array([[2, 3], [4, 5], [6, 1], [8, 9]]),
        np.array([[0, 1], [2, 3], [4, -1], [6, 7]])
    ]

    print(find_boundary_for_points(points_list, "left"))  # Output: 0
    print(find_boundary_for_points(points_list, "right"))  # Output: 8
    print(find_boundary_for_points(points_list, "top"))  # Output: 9
    print(find_boundary_for_points(points_list, "bottom"))  # Output: -1

