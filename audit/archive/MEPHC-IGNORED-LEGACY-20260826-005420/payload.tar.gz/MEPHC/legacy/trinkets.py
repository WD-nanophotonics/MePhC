
import math
import numpy as np
from numpy.fft import fft2, fftshift, fftfreq
from scipy.optimize import curve_fit
from scipy.interpolate import RegularGridInterpolator
from typing import List, Tuple
def triangular_lattice(length, width, a):
    """
    Generate triangular lattice coordinates within a rectangle:
        x in [0, length], y in [-width/2, width/2]

    Parameters:
        length (float): extent along x
        width (float): extent along y
        a (float): lattice spacing

    Returns:
        list of (x, y) tuples
    """
    coords = []
    dy = math.sqrt(3) / 2 * a
    ny = int(width / dy) + 2  # number of rows in y
    nx = int(length / a) + 2  # number of columns in x

    for j in range(-ny, ny + 1):
        y = j * dy
        if -width / 2 <= y <= width / 2:
            # x shift depends on row parity
            x_offset = (a / 2) if (j % 2 != 0) else 0
            for i in range(nx):
                x = i * a + x_offset
                if 0 <= x <= length:
                    coords.append((x, y))
    return coords


def polygon(
    center: Tuple[float, float],
    radius: float,
    n: int,
    rotation: float = 0.0
) -> List[Tuple[float, float]]:
    cx, cy = center
    vertices = []

    for i in range(n):
        angle = rotation + 2 * math.pi * i / n
        x = cx + radius * math.cos(angle)
        y = cy + radius * math.sin(angle)
        vertices.append((x, y))

    return vertices
def semicircle_step_polygon(center=(0, 0), r=10, N=8):
    xc, yc = center
    
    # Step 1: arc points from top to bottom (left semicircle)
    angles = np.linspace(np.pi / 2, 3 * np.pi / 2, N + 1)
    arc_points = [(r * np.cos(a), r * np.sin(a)) for a in angles]
    
    # Step 2: insert axis-aligned step points
    step_points = []
    for i in range(N):
        x1, y1 = arc_points[i]
        x2, y2 = arc_points[i + 1]
        # choose extremal coordinates
        x_chosen = x1 if abs(x1) > abs(x2) else x2
        y_chosen = y1 if abs(y1) > abs(y2) else y2
        step_points.append((x_chosen, y_chosen))
    
    # Step 3: create ports in the required format
    # For each segment, we create 2 ports (2N total)
    ports = []
    
    for i in range(N):
        p1 = arc_points[i]
        step = step_points[i]
        p2 = arc_points[i + 1]
        
        # Port 1: from p1 to step
        dx1 = step[0] - p1[0]
        dy1 = step[1] - p1[1]
        center1 = ((p1[0] + step[0]) / 2, (p1[1] + step[1]) / 2)
        size1 = (abs(dx1), abs(dy1))
        
        # Determine normal direction (perpendicular to the segment)
        if abs(dx1) < 1e-9:  # vertical segment -> normal is x
            direction1 = "x"
        else:  # horizontal segment -> normal is y
            direction1 = "y"
        
        # Port 2: from step to p2
        dx2 = p2[0] - step[0]
        dy2 = p2[1] - step[1]
        center2 = ((step[0] + p2[0]) / 2, (step[1] + p2[1]) / 2)
        size2 = (abs(dx2), abs(dy2))
        
        # Determine normal direction
        if abs(dx2) < 1e-9:  # vertical segment -> normal is x
            direction2 = "x"
        else:  # horizontal segment -> normal is y
            direction2 = "y"
        
        # Apply center offset and add to ports
        ports.append((
            (center1[0] + xc, center1[1] + yc),
            size1,
            direction1
        ))
        ports.append((
            (center2[0] + xc, center2[1] + yc),
            size2,
            direction2
        ))
    
    return ports

def corr_length_gauss(r, C, rmin=0.0, rmax=None):
    """
    Extract correlation length xi assuming Gaussian decay:
    C(r) = A * exp(-r^2 / (2 * xi^2))

    Returns
    -------
    xi, A
    """

    r = np.asarray(r)
    C = np.asarray(C)

    mask = np.isfinite(C) & (C > 0)
    if rmax is not None:
        mask &= (r <= rmax)
    mask &= (r >= rmin)

    r_fit = r[mask]
    C_fit = C[mask]

    def model(r, A, xi):
        return A * np.exp(-r**2 / (2 * xi**2))

    A0 = C_fit[0]
    xi0 = (r_fit[-1] - r_fit[0]) / 2

    popt = curve_fit(model, r_fit, C_fit, p0=(A0, xi0))[0]

    A, xi = popt
    return xi, A

def find_lims(coords):
    """
    Find [x_min, x_max, y_min, y_max] from coords (list/array of (x,y)).
    """
    pts = np.asarray(coords)
    if pts.size == 0:
        return [0,0,0,0]
    x_coords = pts[:,0]
    y_coords = pts[:,1]
    return [float(x_coords.min()), float(x_coords.max()), float(y_coords.min()), float(y_coords.max())]


def radial_g2_periodic(points, boundary, r_edges):
    """
    Compute radial g2(r) treating domain as periodic (toroidal).

    Parameters
    ----------
    points : (N,2) array-like
        Coordinates of points.
    boundary : [x_min, x_max, y_min, y_max]
        Rectangular domain limits.
    r_edges : array-like
        Radial bin edges (length nbins+1).

    Returns
    -------
    r_centers : (nbins,) array
    g2 : (nbins,) array
    counts_per_center : (nbins,) array
    """
    pts = np.asarray(points, dtype=float)
    if pts.ndim != 2 or pts.shape[1] != 2:
        raise ValueError("points must be (N,2)")

    xmin, xmax, ymin, ymax = boundary
    W = float(xmax - xmin)
    H = float(ymax - ymin)
    if W <= 0 or H <= 0:
        raise ValueError("Invalid boundary extents")

    area = W * H
    N = pts.shape[0]
    if N < 2:
        raise ValueError("Need at least two points to compute g2")

    rho = N / area

    r_edges = np.asarray(r_edges, dtype=float)
    if np.any(r_edges < 0):
        raise ValueError("r_edges must be nonnegative and ascending")
    if not np.all(r_edges[:-1] <= r_edges[1:]):
        raise ValueError("r_edges must be monotonic increasing")

    r_centers = 0.5 * (r_edges[:-1] + r_edges[1:])
    dr = r_edges[1:] - r_edges[:-1]

    counts_total = np.zeros_like(r_centers, dtype=float)

    # shift points so domain is [0,W] x [0,H] for convenience
    pts_shifted = pts.copy()
    pts_shifted[:,0] = pts_shifted[:,0] - xmin
    pts_shifted[:,1] = pts_shifted[:,1] - ymin

    # loop over centers to build histogram of minimum-image distances
    # exclude self distance.
    for i,p in enumerate(pts_shifted):
        delta = pts_shifted - p  # shape (N,2)
        # minimum-image convention
        # x-direction
        delta[:,0] = (delta[:,0] + 0.5*W) % W - 0.5*W
        # y-direction
        delta[:,1] = (delta[:,1] + 0.5*H) % H - 0.5*H

        d = np.sqrt(np.sum(delta**2, axis=1))
        # exclude self (distance zero). If duplicates exist and are real, they will have d==0 too.
        mask = d > 1e-12
        d = d[mask]
        hist, _ = np.histogram(d, bins=r_edges)
        counts_total += hist


    # average number of neighbors per center in each bin
    counts_per_center = counts_total / float(N)

    # shell areas in 2D: approx 2*pi*r*dr (suitable for small dr)
    shell_areas = 2.0 * math.pi * r_centers * dr
    g2 = np.zeros_like(r_centers, dtype=float)
    nonzero = shell_areas > 0
    g2[nonzero] = counts_per_center[nonzero] / (rho * shell_areas[nonzero])

    return r_centers, g2, counts_per_center

def FBZ(a=1.0):

    radius = 4 * np.pi / (np.sqrt(3) * a)
    angles = np.linspace(0, 2*np.pi, 7)[:-1]
    verts = np.column_stack([radius/np.sqrt(3) * np.cos(angles),
                             radius/np.sqrt(3) * np.sin(angles)])
    return verts


def SBZ(a=1.0):
    pass


def TBZ(a=1.0):

    radius = 4 * np.pi / (np.sqrt(3) * a)

    angles = np.linspace(0, 2*np.pi, 7)[:-1]+np.pi/6
    verts = np.column_stack([radius * np.cos(angles), radius * np.sin(angles)])
    return verts


def cycle_seed(i):
    """
    Deterministically set numpy global RNG seed based on an integer i.
    Ensures each ensemble member gets a reproducible but distinct seed.

    Parameters:
        i (int): ensemble index
    """
    # mapping must give distinct seeds; xor prevents trivial sequences
    base = 1234567
    seed = base ^ (i * 7919)  # 7919 is a large prime to scatter seeds
    np.random.seed(seed)


def structure_factor_fft(points, boundary, ngrid=512, pad_factor=1, window=True):
    """
    Compute 2D structure factor S(k) via FFT of gridded density.

    Parameters
    ----------
    points : (N,2) array_like
        Point coordinates.
    boundary : [xmin, xmax, ymin, ymax]
        Simulation box limits (use initial unperturbed box).
    ngrid : int
        Base grid size per dimension (before padding).
    pad_factor : int
        Additional zero-padding factor (>=1); increases k-resolution.
    window : bool
        Apply a separable Hann window to reduce FFT ringing (optional).

    Returns
    -------
    kx : 1D array of length M
    ky : 1D array of length M
    Sk2d : 2D array shape (M,M)  -- shifted so k=0 at center
    """
    pts = np.asarray(points, dtype=float)
    xmin, xmax, ymin, ymax = boundary
    Lx = float(xmax - xmin)
    Ly = float(ymax - ymin)
    N = len(pts)

    # grid dims and padding
    Nx = int(ngrid * pad_factor)
    Ny = int(ngrid * pad_factor)

    # map points to grid indices [0..Nx-1], [0..Ny-1]
    # using linear mapping: x-> (x-xmin)/Lx * Nx
    xi = ((pts[:,0] - xmin) / Lx) * Nx
    yi = ((pts[:,1] - ymin) / Ly) * Ny

    # integer binning: use np.floor and clip
    ix = np.floor(xi).astype(int) % Nx
    iy = np.floor(yi).astype(int) % Ny

    rho_grid = np.zeros((Ny, Nx), dtype=float)  # note: array indexing as [y,x]
    # accumulate counts (simple nearest-grid-cell assignment)
    for i,j in zip(ix, iy):
        rho_grid[j, i] += 1.0

    # optional window to reduce spectral leakage (Hann separable)
    if window:
        wx = 0.5 * (1 - np.cos(2*np.pi * (np.arange(Nx)+0.5)/Nx))
        wy = 0.5 * (1 - np.cos(2*np.pi * (np.arange(Ny)+0.5)/Ny))
        w2d = np.outer(wy, wx)
        rho_grid = rho_grid * w2d
        # Note: window changes absolute intensities; for qualitative comparison it's fine.

    # FFT and shift
    Rk = fft2(rho_grid)
    Rk_shift = fftshift(Rk)
    Sk = (np.abs(Rk_shift)**2) / float(N)   # S(k) = 1/N |sum e^{-ik·r}|^2, grid factor accounted by binning

    # create kx, ky arrays (shifted)
    kx_uns = 2*np.pi * fftfreq(Nx, d=Lx/Nx)  # frequencies cycles per length -> multiply by 2pi
    ky_uns = 2*np.pi * fftfreq(Ny, d=Ly/Ny)
    kx = fftshift(kx_uns)
    ky = fftshift(ky_uns)

    return kx, ky, Sk

def structure_factor_windowed(points, k_range, ngrid):
    """
    Compute S(k) only on a selected rectangular k-window.

    Parameters
    ----------
    points : (N,2) array
        Real-space coordinates.
    k_range : tuple
        (kx_min, kx_max, ky_min, ky_max)
    ngrid : int
        Sampling grid per dimension inside the requested k-window.

    Returns
    -------
    kx, ky : 1D arrays (ngrid,)
        k-grid axes
    Sk2d : (ngrid, ngrid) array
        S(k) computed only in the requested region
    """
    pts = np.asarray(points)
    N = len(pts)

    kx_min, kx_max, ky_min, ky_max = k_range

    # build k sampling grid
    kx = np.linspace(kx_min, kx_max, ngrid)
    ky = np.linspace(ky_min, ky_max, ngrid)
    KX, KY = np.meshgrid(kx, ky)

    Sk2d = np.zeros((ngrid, ngrid), dtype=float)

    # compute S(k) = |sum exp(-ik·r)|^2 / N
    for iy in range(ngrid):
        ky_val = ky[iy]
        # compute dot products with all points once per row for performance
        phase_y = pts[:, 1] * ky_val

        for ix in range(ngrid):
            kx_val = kx[ix]
            phase_x = pts[:, 0] * kx_val
            phase = np.exp(-1j * (phase_x + phase_y))
            Sk2d[iy, ix] = np.abs(np.sum(phase))**2 / N

    return kx, ky, Sk2d



if __name__=="__main__":
    import matplotlib.pyplot as plt
    # =============== 1. Generate a triangular lattice ===============
    length = 50.0  # domain in x
    width = 50.0  # domain in y
    a = 1.0  # lattice spacing

    points = np.array(triangular_lattice(length, width, a))

    # =============== 2. Apply small disorder (optional) ===============
    delta_max = 0.01 * a
    points +=np.random.uniform(
            -delta_max, delta_max, points.shape
        )

    # bounding box for FFT density field
    box = find_lims(points)  # [xmin, xmax, ymin, ymax]

    # =============== 3. Compute Sk using FFT ===============
    gridN = 256  # FFT sampling resolution (power of 2 ideal)

    kx, ky, Sk = structure_factor_fft(points, box, gridN)

    # ================= 4. Plot magnitude: |S(k)| ======================

    plt.figure(figsize=(5, 4))
    plt.imshow(np.fft.fftshift(Sk), extent=[kx.min(), kx.max(), ky.min(), ky.max()],
               origin='lower', aspect='equal')
    plt.title("Structure Factor |S(k)|")
    plt.colorbar(label="Intensity")
    plt.xlabel("$k_x$")
    plt.ylabel("$k_y$")
    plt.tight_layout()
    plt.show()
