import numpy as np
import datetime
import glob
import shutil
import os
import pickle
import inspect
import re
from typing import Type, TypeVar, List, Tuple
from colorama import Fore, Style
from config import *
'This file stores relatively irrelavent functions'
rt2 = np.sqrt(2)
rt3 = np.sqrt(3)
pi=np.pi


def normalize_freq(actual_a, actual_freq):
    if isinstance(actual_freq, (list, np.ndarray)):
        # Recursively normalize each element
        return [normalize_freq(actual_a, freq) for freq in actual_freq]
    else:
        # Base case: normalize a single frequency
        return 1000 * actual_freq * actual_a / c_const0
    
def denormalize_freq(actual_a, norm_freq):
    if isinstance(norm_freq, (list, np.ndarray)):
        # Recursively denormalize each element
        return [denormalize_freq(actual_a, freq) for freq in norm_freq]
    else:
        # Base case: denormalize a single frequency
        return  norm_freq*c_const0/actual_a /1000    
def round_array(arr, decimals=5):
    return np.around(arr, decimals=decimals)

def is_simple_numeric_pair(data):
    if isinstance(data, (list, tuple)) and len(data) == 2:
        if all(isinstance(item, (int, float)) for item in data):
            return True
    return False


def get_data_structure(data):
    if isinstance(data, np.ndarray):
        return f'np.array:{data.shape}'
    if is_simple_numeric_pair(data):
        return "numeric_pair"
    elif isinstance(data, list):
        sub_structure = []
        for item in data:
            sub_structure.append(get_data_structure(item))


        return sub_structure
    return 'unknown'

def flatten(lst):
    flat_list = []
    for item in lst:
        if isinstance(item, list):
            flat_list.extend(flatten(item))
        else:
            flat_list.append(item)
    return flat_list




def is_one_layer_pattern_list(data): # np arrays stored in a list, the standard data structure for lattice dots.
    if isinstance(data, list):
        return all(isinstance(item, np.ndarray) for item in data)
    return False

def is_two_layer_pattern_list(data):# one layer patter lists stored in a list, the standard data structure for patterned lattice.
    if isinstance(data, list):
        return all(is_one_layer_pattern_list(item) for item in data)
    return False


def convert_to_two_layer_pattern_list(data):
    result=[]
    if isinstance(data, list):
        if is_two_layer_pattern_list(data):
            return data
        elif is_one_layer_pattern_list(data):
            return [data]
        else:
            for item in data:
                result+=convert_to_two_layer_pattern_list(item)
            return result
    elif isinstance(data, np.ndarray):
        return [[data]]
    else:
        raise ValueError("Invalid data type provided.")


def convert_to_one_layer_pattern_list(data):
    result=[]
    if isinstance(data, list):
        if is_one_layer_pattern_list(data):
            return data
        elif is_two_layer_pattern_list(data):
            return [item for sublist in data for item in sublist]
        else:
            for item in data:
                result+=convert_to_one_layer_pattern_list(item)
            return result
    elif isinstance(data, np.ndarray):
        return [data]

    else:

        raise ValueError("Invalid data type provided.")

def numpy_array_to_tuples(numpy_array):
    """
    Converts a (N, 2) shaped NumPy array to a list of 2-element tuples.

    Args:
        numpy_array (numpy.ndarray): NumPy array with shape (N, 2).

    Returns:
        list: List of 2-element tuples.
    """
    # Ensure the input is a NumPy array with 2 columns
    if numpy_array.shape[1] != 2:
        raise ValueError("Input array must have 2 columns.")

    # Convert the NumPy array to a list of tuples
    tuples_list = [tuple(row) for row in numpy_array]
    return tuples_list

class HashableList:
    def __init__(self, input_list):
        self.tuple_representation = tuple(input_list)

    def get_tuple(self):
        return self.tuple_representation

    def get_list(self):
        return list(self.tuple_representation)

# some functions to analyse the structure of a nested list
def count_dict(lst):
    element_count_dict = {}

    # Loop through the list and count the occurrences of each element
    for element in lst:
        if element in element_count_dict:
            element_count_dict[element] += 1
        else:
            element_count_dict[element] = 1
    return element_count_dict

def convert_simple_list(lst):
    element_count_dict = count_dict(lst)
    result = []
    for element, count in element_count_dict.items():
        if count > 1:
            result.append(f"{count}×{element}")
        else:
            result.append(element)
    return [','.join(result)]


def convert_nested_list(nested_list):
    result = []
    for lst in nested_list:
        result.append(convert_simple_list(lst))
    return result
def are_lists_equal(list1, list2):
    # Check if the lengths of the lists are equal
    if len(list1) != len(list2):
        return False

    # Count occurrences of each element in both lists
    count_dict1 = {}
    count_dict2 = {}

    for item in list1:
        if isinstance(item, list):
            # If the item is a nested list, recursively count its elements
            item_count = are_lists_equal(item, item)
            if item_count is False:
                return False
            count_dict1[str(item)] = int(item_count)
        else:
            count_dict1[str(item)] = count_dict1.get(str(item), 0) + 1

    for item in list2:
        if isinstance(item, list):
            # If the item is a nested list, recursively count its elements
            item_count = are_lists_equal(item, item)
            if item_count is False:
                return False
            count_dict2[str(item)] = int(item_count)
        else:
            count_dict2[str(item)] = count_dict2.get(str(item), 0) + 1
    print(f"count_dict1: {count_dict1}")
    print(f"count_dict2: {count_dict2}")

    return count_dict1 == count_dict2

def count_dict_for_list_items(lst):
    # Initialize a dictionary to store the counts of sublists
    sublist_count_dict = {}

    # Loop through the list
    for item in lst:
        if isinstance(item, list):
            # Convert the sublist to a string for dictionary key
            item_str = str(item)

            # Check if the sublist is already in the dictionary
            if item_str in sublist_count_dict:
                sublist_count_dict[item_str] += 1
            else:
                sublist_count_dict[item_str] = 1

    return sublist_count_dict

def convert_simple_2_layer_list(lst):
    sublist_count_dict = count_dict_for_list_items(lst)
    result = []
    for sublist, count in sublist_count_dict.items():
        if count > 1:
            result.append(f"{count}×{sublist}")
        else:
            result.append(sublist)
    return [','.join(result)]

def get_data_structure_lite(data):
    abstract_data=convert_nested_list(get_data_structure(data))
    result=convert_simple_2_layer_list(abstract_data)
    print(result)


def current_datetime_as_string():
    now = datetime.datetime.now()
    formatted_datetime = now.strftime("%Y%m%d%H%M%S")
    return formatted_datetime


def sanitize_filename(filename):
    # Replace curly braces `{}` and square brackets `[]` with parentheses `()`
    filename = re.sub(r'\{', '(', filename)
    filename = re.sub(r'\}', ')', filename)
    filename = re.sub(r'\[', '(', filename)
    filename = re.sub(r'\]', ')', filename)
    # Replace colons `:` with underscores `_`
    filename = re.sub(r':', '_', filename)
    # Trim leading and trailing whitespace
    filename = filename.strip()
    # Replace multiple spaces or tabs with a single comma
    filename = re.sub(r'\s+', ',', filename)
    return filename


def save_data(data, filename):
    """
    Save data to a file with the given filename.

    Parameters:
    data: The data to save. Can be a numpy array, list, tuple, string, or dictionary.
    filename: The name of the file to save the data to. The function will automatically add the appropriate extension.
    """
    # Sanitize the filename to avoid issues with special characters
    filename = sanitize_filename(filename)


    if not filename.endswith('.pkl'):
        filename += '.pkl'
    with open(filename, 'wb') as file:
        pickle.dump(data, file)


def load_data(filename):
    """
    Load data from a file with the given filename.

    Parameters:
    filename: The name of the file to load the data from.

    Returns:
    The data loaded from the file.
    """
    # Sanitize the filename to match the saved file
    filename = sanitize_filename(filename)

    # Check if the filename already has an extension
    if not os.path.splitext(filename)[1]:  # If no extension is found
        # Find files with matching base name and any extension
        files = glob.glob(f"{filename}.*")
        if not files:
            raise FileNotFoundError(f"No file found for base name: {filename}")
        real_file = files[0]  # Use the first matching file
    else:
        # Use the filename as is if it already has an extension
        real_file = filename

    # Load the data based on the file extension
    with open(real_file, 'rb') as file:
        if real_file.endswith('.npy'):
            return np.load(file, allow_pickle=True)
        else:
            return pickle.load(file)


def file_exists_without_extension(filename):
    filename = sanitize_filename(filename)
    # Search for any file that starts with `filename` and has any extension
    base_name = os.path.splitext(filename)[0]  # Remove any existing extension if present
    # Search for any file with the base name and any extension
    files = glob.glob(f"{base_name}.*")
    # Check if any matching files exist
    return len(files) > 0

def find_closest_value(lst, target):

    if not lst:
        raise ValueError("The list is empty.")
    
    closest_value = min(lst, key=lambda x: abs(x - target))
    return closest_value  

def find_and_move_files(directory, keyword,file_identifier="_"):
    # Check if the directory exists
    if not os.path.exists(directory):
        print(f"Directory '{directory}' does not exist.")
        return

    # Create a folder for the keyword
    keyword_folder = os.path.join(directory, keyword)
    os.makedirs(keyword_folder, exist_ok=True)

    # Get a list of files with the keyword in the directory
    matching_files = glob.glob(os.path.join(directory, f"*{file_identifier}{keyword}*"))

    if not matching_files:
        print(f"No files found with the keyword '{file_identifier}{keyword}' in the directory.")
        return

    # Move matching files to the keyword folder
    for file_path in matching_files:
        file_name = os.path.basename(file_path)
        destination_path = os.path.join(keyword_folder, file_name)

        # If a file with the same name exists in the keyword folder
        if os.path.exists(destination_path):
            os.remove(destination_path)
            print(f"Removed existing file '{destination_path}'.")

        # Move the file to the keyword folder
        shutil.move(file_path, destination_path)
        print(f"Moved '{file_path}' to '{destination_path}'.")

    print(f"All files with the keyword '{keyword}' have been moved to '{keyword_folder}'.")


def filter_files_by_keywords(directory: str, keywords: List[str], negative_keywords: List[str]) -> List[str]:
    """
    Returns a list of file paths in the given directory that contain at least one keyword
    from `keywords` but do not contain any keyword from `negative_keywords`.
    
    :param directory: Path to the directory
    :param keywords: List of keywords that must be included in the filename
    :param negative_keywords: List of keywords that must not be included in the filename
    :return: List of file paths satisfying the conditions
    """
    if not os.path.isdir(directory):
        raise ValueError(f"The provided directory '{directory}' is not valid.")
    
    matching_files = []
    
    for file_name in os.listdir(directory):
        file_path = os.path.join(directory, file_name)
        
        if os.path.isfile(file_path):
            # Check if filename contains any of the required keywords
            if all(keyword in file_name for keyword in keywords):
                # Ensure filename does not contain any negative keyword
                if not any(neg_keyword in file_name for neg_keyword in negative_keywords):
                    matching_files.append(file_path)
    
    return matching_files

def read_txt_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        x, y = np.genfromtxt(f, comments='%', unpack=True)
    return x, y

def get_dir_with_keywords(main_dir, kwl):

    if not os.path.isdir(main_dir):
        raise FileNotFoundError(f"Main directory '{main_dir}' does not exist or is not a directory.")
    
    candidates = []
    
    for subdir in os.listdir(main_dir):
        subdir_path = os.path.join(main_dir, subdir)
        if os.path.isdir(subdir_path) and all(kw in subdir for kw in kwl):
            candidates.append(subdir_path)
    
    if len(candidates) == 0:
        raise FileNotFoundError("No directory matches the given keywords.")
    elif len(candidates) > 1:
        raise ValueError(f"Multiple directories match the criteria: {candidates}")
    
    return candidates[0]


def clear_or_create_folder(directory,name,verbal=0): # if the folder exists, clear it. If not, create it.
    folder_path=os.path.join(directory,name)
    if os.path.exists(folder_path):
        if verbal:
            print(f"Clearing folder {folder_path}")
        shutil.rmtree(folder_path)
    os.makedirs(folder_path)

def stringlize(container, delimiter=","):
    if isinstance(container, (list, tuple)):
        return delimiter.join(str(elem) for elem in container)

    elif isinstance(container, dict):
        return delimiter.join(f"{key}={value}" for key, value in container.items())

    else:
        return str(container)
    
def extract_and_convert(main_str, left_str, right_str, data_type=float):
        try:
                # Find the indices of the left and right strings
                start_idx = main_str.index(left_str) + len(left_str)
                end_idx = main_str.index(right_str, start_idx)

                # Extract the substring
                substring = main_str[start_idx:end_idx].strip()

                # Convert to the specified data type (default is float)
                return data_type(substring)

        except ValueError as e:
                print(f"Error: {e}")
                return None

def remove_after_last_keyword(s: str, keyword: str) -> str:
    """
    Removes everything from the last occurrence of `keyword` to the end of the string, including the keyword.

    Parameters:
        s (str): The original string.
        keyword (str): The keyword to search for.

    Returns:
        str: The truncated string.
    """
    index = s.rfind(keyword)
    if index == -1:
        return s  # Keyword not found, return original string
    return s[:index]


def get_method_args(include_self=False, negative_filter=None):
    negative_filter = negative_filter or []

    frame = inspect.currentframe().f_back
    args_dict = frame.f_locals
    func_name = frame.f_code.co_name

    # Get class name if it's a method
    if 'self' in args_dict:
        class_name = args_dict['self'].__class__.__name__
        full_name = f"{class_name}.{func_name}"
        method = getattr(args_dict['self'].__class__, func_name)
        sig = inspect.signature(method)
    else:
        full_name = func_name
        sig = inspect.signature(frame.f_globals[func_name])

    param_names = list(sig.parameters.keys())

    if not include_self and 'self' in param_names:
        param_names.remove('self')

    def should_include(name, value):
        for keyword in negative_filter:
            if keyword in name or keyword in str(value):
                return False
        return True

    args_str = "_".join(
        f"{name}={stringlize(args_dict[name], ',')}"
        for name in param_names
        if name in args_dict and should_include(name, args_dict[name])
    )

    return args_str


def time_consumption_log(start,end):
    time_diff=end-start
    time_diff_str = (f"{time_diff.seconds} seconds" if time_diff.seconds < 60
                     else f"{time_diff.seconds // 60} minutes {time_diff.seconds % 60} seconds")
    #print(f"Time taken to generate data: {time_diff_str}")
    #print in blue text
    print(f"{Fore.BLUE}Time taken to generate data: {time_diff_str}{Style.RESET_ALL}")
T = TypeVar("T")  # Generic type variable
def assign_dict_as_arguments(func:Type[T],dic)-> T:
    valid_keys = inspect.signature(func).parameters.keys()
    filtered_dict = {}
    for k, v in dic.items():
        if k in valid_keys:
            filtered_dict[k] = v

    return func(**filtered_dict)