working_dir = "/home/icy/MePhC"
input_dir="input"
imag_dir="imag"
data_dir="data"

fname_lattice="lattice_data.pkl"
fname_geo_param="geo_params.pkl"
fname_sim_param="sim_params.pkl"
fname_data_param="data_params.pkl"
c_const0=299792458
si_n_eff=2.7