from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.spatial import Delaunay
from shapely.geometry import Point, Polygon

import e7i1g_geometry as base
import e7i1g_geometry_v5 as v5

ROOT = Path("/mnt/c/Users/icywo/PycharmProjects/MePhC-Windows")


def with_extra(limit, extra_points):
    points_all = list(v5.mesh(limit)["points_abs"]) + list(extra_points)
    unique = {tuple(round(value, 12) for value in point): point for point in points_all}
    points = np.asarray(list(unique.values()), dtype=float)
    triangles = []
    for piece in base.pieces:
        ids = [index for index, point in enumerate(points) if piece.covers(Point(point))]
        local = points[ids]
        for simplex in Delaunay(local).simplices:
            triangle_points = local[simplex]
            triangle = Polygon(triangle_points.tolist())
            if not piece.covers(triangle) or triangle.area <= 1e-12:
                continue
            if base.max_edge(triangle_points) <= limit + 1e-8:
                triangles.append([tuple(point) for point in triangle_points])
            else:
                triangles.extend(base.refine([tuple(point) for point in triangle_points], limit))
    point_ids, final_points, indexed = {}, [], []
    for triangle in triangles:
        indices = []
        for point in triangle:
            key = tuple(round(value, 12) for value in point)
            if key not in point_ids:
                point_ids[key] = len(final_points)
                final_points.append(list(point))
            indices.append(point_ids[key])
        if len(set(indices)) == 3:
            indexed.append(indices)
    return {"points_abs": final_points, "points_offset_K": [[p[0] - base.K[0], p[1] - base.K[1]] for p in final_points], "triangles": indexed}


coarse = v5.mesh(.06)
fine = with_extra(.03, coarse["points_abs"])
output = {"coordinate_space": "public_q=k_phys*a/(2*pi)", "reciprocal_basis": {"g1": base.G1.tolist(), "g2": base.G2.tolist()}, "K": base.K.tolist(), "Kp": base.KP.tolist(), "bz_polygon": base.BZ.tolist(), "area_bz": base.Polygon(base.BZ.tolist()).area, "area_voronoi_K": base.region.area, "expected_area_bz": 2.0 / base.SQRT3, "expected_area_voronoi_K": 1.0 / base.SQRT3, "pieces": [list(map(list, piece.exterior.coords))[:-1] for piece in base.pieces], "coarse": coarse, "fine": fine, "max_coarse_edge": max(base.max_edge([coarse["points_abs"][i] for i in triangle]) for triangle in coarse["triangles"]), "max_fine_edge": max(base.max_edge([fine["points_abs"][i] for i in triangle]) for triangle in fine["triangles"]), "fine_contains_coarse_vertices": all(tuple(round(value, 12) for value in point) in {tuple(round(value, 12) for value in other) for other in fine["points_abs"]} for point in coarse["points_abs"]), "tie_convention": "half_open_storage_boundary_measure_zero", "stored_reuse_policy": "exact_identity_reuse_only_when_mesh_vertex_matches"}
(ROOT / ".e7i1g_geometry.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
print(json.dumps({"event": "geometry_v7_complete", "pieces": len(base.pieces), "area_bz": output["area_bz"], "area_voronoi_K": output["area_voronoi_K"], "coarse_points": len(coarse["points_abs"]), "coarse_triangles": len(coarse["triangles"]), "fine_points": len(fine["points_abs"]), "fine_triangles": len(fine["triangles"]), "max_coarse_edge": output["max_coarse_edge"], "max_fine_edge": output["max_fine_edge"], "fine_contains_coarse_vertices": output["fine_contains_coarse_vertices"]}, indent=2))
