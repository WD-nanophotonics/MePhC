import json, math
from pathlib import Path
import numpy as np

root=Path('/mnt/c/Users/icywo/PycharmProjects/MePhC-Windows')
spec=json.loads((root/'.m1_results/spectral_manifest.json').read_text())
def log_result(path):
    data=path.read_bytes()
    for enc in ('utf-8','utf-16'):
        try: text=data.decode(enc); break
        except UnicodeDecodeError: continue
    return json.loads(next(x for x in text.splitlines() if x.startswith('{"event": "result"')))
centers={96:log_result(root/'.m1_results/center96.log'),128:log_result(root/'.m1_results/center128_retry.log')}
rows=[]
for t in spec['tasks']:
    ev=next(x for x in t['events'] if x.get('event')=='result')
    rows.append((t['resolution'],t['qmag'],t['direction'],ev['frequencies'][1]-ev['frequencies'][0]))
out={}
for R in (96,128):
    gap0=centers[R]['frequencies'][1]-centers[R]['frequencies'][0]; m=gap0/2; groups=[]
    for q in (.005,.01,.015,.02):
        vals=[x[3] for x in rows if x[0]==R and abs(x[1]-q)<1e-12]; avg=float(np.mean(vals))
        vs=[math.sqrt(max(0,(g/2)**2-m*m))/q for g in vals]
        groups.append({'q':q,'gap_mean':avg,'directional_spread':float(max(vals)-min(vals)),'v_each':vs,'v_mean':float(np.mean(vs))})
    qs=np.array([g['q'] for g in groups]); y=np.array([(g['gap_mean']/2)**2-m*m for g in groups])
    v=float(math.sqrt(max(0,float(np.dot(qs*qs,y)/np.dot(qs*qs,qs*qs)))))
    pred=2*np.sqrt(m*m+(v*qs)**2); rmse=float(np.sqrt(np.mean((pred-np.array([g['gap_mean'] for g in groups]))**2)))
    out[R]={'center_gap':gap0,'m':m,'groups':groups,'v_fit':v,'gap_rmse':rmse}
print(json.dumps(out,indent=2))
