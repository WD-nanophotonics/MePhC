# C1 Result Report

WORK_ORDER_ID=TRILATT-E7I1A6-C1-20260821-020
ACTION=REPORT_RESULT
PROJECT_ID=TRILATT
BASELINE_COMMIT=3655ed050afd39a2befe5c739759a20af2a3036f

## Scope

This report covers only the bounded C1 corrective. No full R-by-h matrix, large scan, Dirac fit, E7I.1B work, policy change, or production-code change was performed.

## Provenance and coordinates

D0500_PROVENANCE=EXACTLY_RECOVERED
CENTER_COORDINATE_STATUS=PRIOR_D0500_USES_DIFFERENT_BUT_DOCUMENTED_CENTERS
D0500_K_MAPPING=EXACT_PRIOR_VALLEY_RECOVERED

The surviving source is MPBBC/geo_gen.py with legacy boundary code in MPBBC/bc_gen.py. Exact parameters are a=400, r1=125, r2=100, honeycomb pattern, triangular lattice, background index 2.65, inclusion index 1.0, TE, and public legacy K=(2/3,0).

The exact source direct basis is a1=(0.5,sqrt(3)/2), a2=(0.5,-sqrt(3)/2). Its public Cartesian-to-MPB reciprocal mapping is B=A^(-T)=[[1,1],[0.5773502691896257,-0.5773502691896258]], so (2/3,0)->(1/3,1/3). Other cardinal candidates map as: (-2/3,0)->(-1/3,-1/3), (0,2/3)->(0.5773502692,-0.5773502692), and (0,-2/3)->(-0.5773502692,0.5773502692).

The source-generated honeycomb pattern centers are layer 1=(0.25,0.3) and layer 2=(0.75,0.5886751345948128). The rectified MPB lattice-coordinate centers in the legacy geometry log are approximately (0.423205,0.0767949) and (1.08987,0.410128). These are the original triangular prisms, not the temporary circular inclusions at (+1/6,0) and (-1/6,0) used by the failed near-zero experiment.

Audit finding: the C1 prompt's alternate basis a1=(sqrt(3)/2,1/2), a2=(sqrt(3)/2,-1/2) is not the basis in the surviving MPBBC source. Under the surviving source basis, (1/6,1/6) maps to (1/6,0), not (sqrt(3)/6,0). The source geometry itself remains exactly recoverable.

## Legacy anchor

PRIOR_D0500_ANCHOR=COMPATIBLE_WITH_RECORDED_NUMERICAL_TOLERANCE

The exact source geometry and legacy E+H overlap path were run at R=48, h=0.001, public K=(2/3,0), TE. The Berry scalars were band 1=40.36601539192835, band 2=-40.446467208408485, band 3=-0.07241671018928303. The surviving R=128 reference records approximately 38.043, -38.005, and -0.048 for the same anchor family. The R=48 result is compatible in sign, scale, ordering, and residual scale; it is not a claim of resolution identity.

## Current E+H sanity point

EH_WEAK_MASS_SANITY=COHERENT_WITH_PRIOR_PHYSICS

The current MPBLiveEnergySpectralProvider and mpb_live_energy_eh_v1 were run on the exact source geometry at R=48, h=0.001, K=(2/3,0), TE, using the centered four-vertex plaquette. Frequencies were [0.2840475675,0.2928848156,0.3399052769], [0.2840431371,0.2928859379,0.3399080101], [0.2840432472,0.2928858565,0.3399079831], and [0.2840476763,0.2928847358,0.3399052495]. Maximum off-diagonal Gram magnitudes were 0.00249, 0.00246, 0.00246, and 0.00249.

Scaled Berry values were band 1=40.50643430768483, band 2=-40.58915814581180, band 3=-0.07249691757808. The anti-symmetric band-1/band-2 mass is approximately 40.5477962 and the common component approximately -0.0413619.

NEAR_ZERO_CAUSE=WRONG_CENTER_COORDINATES

The earlier near-zero value came from the temporary two-circle geometry with redefined centers, not the exact d0500 source geometry. The exact reproduction restores the expected O(40) band-1/band-2 response. The prior K mapping is recovered exactly and is not the primary cause.

## Bounded resource diagnostics

MPB_RESOURCE_CAUSE=MIXED

A raw R=32 MPB probe showed approximately 132 MB before construction, 134.4 MB after solve and E/H extraction, and flat RSS after deletion and garbage collection; solver reuse was also flat. A current-provider R=48 probe with four solves showed: before provider 123.13 MB; after provider 123.20 MB; after solves 140.96, 142.96, 142.97, 142.97 MB; after deleting each snapshot 136.96, 136.96, 136.97, 136.97 MB; after provider deletion 136.97 MB.

This establishes temporary native allocation and allocator retention during provider solves, but not unbounded growth in this bounded run. The raw probe does not show a Python reference leak. Previous WSL instability occurred during a much larger experiment and cannot be attributed to one confirmed Python leak from this evidence.

RESOURCE_SAFE_STRATEGY=ANOTHER_DOCUMENTED_STRATEGY

Recommended path: isolate each bounded resolution/geometry/valley batch in a fresh child process, keep the batch small, enforce an RSS ceiling, serialize result metadata before process exit, and terminate the child normally after the batch. Do not run a full matrix in one process. Solver reuse within one child is acceptable only for a bounded batch after observing the RSS ceiling; process isolation remains the reclamation boundary.

## Disposition

C1_OVERALL=COORDINATE_PROVENANCE_CLOSED_AND_EXECUTION_PATH_READY

The prior geometry, centers, and K mapping are recovered. The wrong-center experiment is identified as the cause of the near-zero observation. The corrected E+H sanity point is coherent with the legacy anchor. Resource behavior is bounded and has a documented process-isolation strategy. E7I.1B and any large matrix remain unauthorized by this report.
