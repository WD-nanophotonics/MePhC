# C2 Result Report

WORK_ORDER_ID=TRILATT-E7I1A6-C2-20260821-022
ACTION=REPORT_RESULT
PROJECT_ID=TRILATT
BASELINE_COMMIT=3655ed050afd39a2befe5c739759a20af2a3036f

## Artifact inventory

The following surviving artifacts were inspected read-only:

1. `GmailCourier/outbox/TRILATT/TRILATT-E7I1A1-20260820-025/message.txt` contains the original E7I.1A.1 compact result and the fixed true-E7I geometry contract.
2. `GmailCourier/outbox/TRILATT/TRILATT-E7I1A2-20260820-026/message.txt` contains the d045/d050/d060/d070 spectral and antisymmetric-curvature sweep, including the d050 anchor.
3. `GmailCourier/outbox/TRILATT/TRILATT-E7I1A4-20260820-028/message.txt` contains the d0500 stage-2 anchor, exact center frequencies, Delta0, Gext, v_fit, Omega_anti, and common ratio.
4. `GmailCourier/outbox/TRILATT/TRILATT-E7I1A5-20260820-029/message.txt` contains the R24/R32/R48 and h=.0025/.00125/.000625 convergence records and the full d0500/d0505 classifications.
5. `ChatCourier/requests/TRILATT-E7I1A-REF6.1-20260821-017/response.txt` contains the later canonical-geometry discussion and confirms that the unresolved literature-paper reconstruction is not a substitute for the explicit E7I d0500 contract.
6. Current source inspected read-only: `MePhC/mephc/berry.py`, `MePhC/mephc/mpb_spectral.py`, `MePhC/mephc/mpb_spectral_provider.py`, `MePhC/mephc/mpb_energy_spectral_provider.py`, and the E7E/R6 tests.

No standalone original E7I script was required: the compact historical contract and recorded numerical artifact contain the constructor arguments and observable conventions needed for reproduction.

## True E7I d0500 provenance

E7I_D0500_PROVENANCE=EXACTLY_RECOVERED

The true E7I d0500 model is Family B, not the legacy MPBBC 125/100 model:

    lattice basis 1 = (sqrt(3)/2,  1/2)
    lattice basis 2 = (sqrt(3)/2, -1/2)
    MPB center A    = ( 1/6,  1/6)
    MPB center B    = (-1/6, -1/6)
    public center A = ( sqrt(3)/6, 0)
    public center B = (-sqrt(3)/6, 0)
    d0500 minus     = radius_A 0.15, radius_B 0.25
    d0500 plus      = radius_A 0.25, radius_B 0.15
    background      = air
    inclusion       = epsilon 12.0
    polarization    = TM
    num_bands       = 6
    resolution      = 32 for the recorded anchor
    mesh_size       = 3
    eigensolver     = 1e-7

The public reciprocal valleys are:

    K  = (0, -2/3) -> MPB reciprocal (-1/3,  1/3)
    Kp = (0,  2/3) -> MPB reciprocal ( 1/3, -1/3)

The target pair is bands 1 and 2, one-based. The plus/minus domain is the A/B radius swap shown above. The center anchor uses the public K or Kp point and the historical forward CCW plaquette.

## Family comparison

BENCHMARK_FAMILY_RELATION=DISTINCT_PHYSICAL_MODELS

| attribute | LEGACY_MP BBC_125_100 | TRUE_E7I_D0500 |
|---|---|---|
| basis | (0.5,+/-sqrt(3)/2) | (sqrt(3)/2,+/-0.5) |
| geometry | source-generated honeycomb triangular prisms | two explicit circular inclusions |
| centers | (0.25,0.3), (0.75,0.588675...) from source generator | MPB centers (+/-1/6,+/-1/6) |
| size parameters | a=400, r1=125, r2=100 | radii 0.15 and 0.25 for d0500 |
| material path | background index 2.65, inclusion index 1.0 | air background, inclusion epsilon 12 |
| polarization | TE | TM |
| public K | (2/3,0) | (0,-2/3), Kp=(0,2/3) |
| target pair | legacy all-band E+H anchor | bands 1 and 2, E7E qualified |
| historical Berry scale | about +/-38 to +/-40 | d0500 anti about +/-12.14264 |

The shared word honeycomb and nonzero Berry curvature do not make these models interchangeable.

## Original d0500 anchor

RECORDED_D0500_ANCHOR_PROVENANCE=EXACTLY_RECOVERED

The recorded R32 d0500 spectral anchor is:

    Delta0       = 0.05964106
    Gext         = 0.09709127
    eta          = 0.61427824
    m_abs        = 0.02982053
    v_fit        = 0.1643994 to 0.16439942
    model_q0     = 15.196368 to 15.196372
    model_q001   = 15.127351 to 15.127355
    radicand_min = 2.59e-06
    valid_count  = 12

The recorded center frequencies for d0500-minus at K are:

    [0.24298778666215168, 0.3026288425489017, 0.3997201143403465,
     0.49575577345159405, 0.6718761706960672, 0.678977532182346]

The historical observable is the E7E live-qualified single-band estimator using the periodic H-only Bloch-envelope representation. Its signed convention is `Omega_est=-phi_W/A_signed`; the historical center path is forward CCW, not the later centered modern path. The recorded finest delta-k is h=0.000625, with the preceding ladder h=.005, .0025, and .00125 in the earlier diagnostics.

At R32, h=.000625, d0500-minus, K, the recorded values are:

    Omega_anti  = -12.14264935
    Omega_common= -2.86352455
    common_ratio= 0.23582370

The Kp and plus records show the expected valley and A/B-swap sign reversals with the same magnitude to the recorded tolerance.

## Single-point true d0500 reproduction

TRUE_D0500_ANCHOR_REPRODUCTION=COMPATIBLE_WITH_RECORDED_NUMERICAL_TOLERANCE

A fresh child process reconstructed the exact true d0500-minus geometry and ran R32, TM, six bands, tolerance 1e-7, mesh size 3, K=(0,-2/3), h=.000625. The MPB frequencies reproduced the recorded center frequencies to the displayed precision.

The original E7E H-only path gave raw Berry values in the current calculator's normalized `(2*pi)^-2` scale:

    band 1 =  0.3801080163384114
    band 2 = -0.23503692805968654

Converting to the historical convention `-phi/A_signed` gives:

    band 1 = -15.0060630038
    band 2 =   9.2788859984
    Omega_anti = -12.1424745011
    Omega_common = -2.8635885027
    common_ratio = 0.235834 approximately

The anti value differs from the recorded -12.14264935 by about 1.75e-4 (relative about 1.4e-5), compatible with the recorded numerical tolerance and independent fresh-process execution. An auxiliary current E+H calculation at the same R32 point gave Omega_anti=-12.1424778591 and Omega_common=-2.8635953534, showing that the representation difference is negligible at this anchor; this auxiliary comparison is not being substituted for the required modern R48 sanity.

## Modern centered E+H sanity

TRUE_D0500_EH_SANITY=NOT_RUN

The authorized modern comparison was prepared as R48, centered CCW, `mpb_live_energy_eh_v1`, h=.01 and h=.001, bands 1 and 2. Both attempts failed before the Python process could start because the WSL service returned `Wsl/Service/E_UNEXPECTED`. The same failure occurred on one retry. No numerical result is claimed for this Part F gate, and no additional retry or larger computation was made.

## C1 near-zero reclassification

C1_NEAR_ZERO_RELATION_TO_TRUE_D0500=PARTIALLY_OVERLAPPING_GEOMETRY_BUT_WRONG_COORDINATES

C1 used a temporary two-circle construction with public Cartesian centers (+1/6,0) and (-1/6,0), the legacy-family basis/convention, and the wrong physical coordinate representation for the true E7I d0500. It shares a broad two-inclusion motif, but it is not the exact true d0500 model. Therefore C1 proves only that the temporary construction can yield a near-zero result; it does not prove a true-d0500 center error. The exact true d0500 reproduction instead gives the recorded O(12.14) antisymmetric scale.

## Resource contract and repository state

D0500_MATRIX_EXECUTION_PLAN=FRESH_PROCESS_PER_RESOLUTION_READY

The C1 raw and provider probes showed temporary native allocation and allocator retention but no demonstrated Python reference leak or unbounded growth in the bounded samples. The safe matrix design remains one fresh child process per resolution, a small bounded batch, immediate serialization, an RSS ceiling, normal process exit, and supervisor manifest verification before the next batch. No full matrix is authorized by C2.

No tracked production file was modified. The temporary C1/C2 probe files were removed after use. Repository verification before report preparation showed:

    HEAD       = 3655ed050afd39a2befe5c739759a20af2a3036f
    origin/main= 3655ed050afd39a2befe5c739759a20af2a3036f
    MePhC worktree = clean after temporary diagnostics were removed

## Required classifications

E7I_D0500_PROVENANCE=EXACTLY_RECOVERED
BENCHMARK_FAMILY_RELATION=DISTINCT_PHYSICAL_MODELS
RECORDED_D0500_ANCHOR_PROVENANCE=EXACTLY_RECOVERED
TRUE_D0500_ANCHOR_REPRODUCTION=COMPATIBLE_WITH_RECORDED_NUMERICAL_TOLERANCE
TRUE_D0500_EH_SANITY=NOT_RUN
C1_NEAR_ZERO_RELATION_TO_TRUE_D0500=PARTIALLY_OVERLAPPING_GEOMETRY_BUT_WRONG_COORDINATES
D0500_MATRIX_EXECUTION_PLAN=FRESH_PROCESS_PER_RESOLUTION_READY
C2_OVERALL=TRUE_D0500_PROVENANCE_CLOSED_PHYSICS_SANITY_PENDING

STOP_AFTER=E7I.1A.6.C2
No matrix, d0500-d0505 scan, E7I.1B, scale-aware policy promotion, or commit/push was performed.
