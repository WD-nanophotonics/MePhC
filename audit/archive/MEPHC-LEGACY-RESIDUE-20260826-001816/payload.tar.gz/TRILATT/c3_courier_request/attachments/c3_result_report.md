# C3 Result Report

WORK_ORDER_ID=TRILATT-E7I1A6-C3-20260821-024
ACTION=REPORT_RESULT
PROJECT_ID=TRILATT
BASELINE_COMMIT=3655ed050afd39a2befe5c739759a20af2a3036f

## Runtime recovery

RUNTIME_RECOVERY=PASS

Initial WSL state:

    MemTotal       = 7907476 kB
    MemAvailable   = 7119992 kB
    SwapTotal      = 2097152 kB
    SwapFree       = 2096568 kB

No stale C1/C2 worker, MPB worker, or zombie process was found. The Miniconda `mp` interpreter imported Meep successfully. A separate unrelated R8 TM smoke solve with one cylinder, one k-point, one band, and no field retention completed with frequency 0.2002059066. WSL printed a non-fatal systemd user-session warning, but the command, Python environment, and MPB smoke all completed normally.

Final state after all C3 children exited:

    MemAvailable   = 7075384 kB
    SwapFree       = 2096568 kB
    running C3 workers = none

No WSL configuration was modified.

## Worker contract

The temporary external harness used one supervisor and a fresh child for each bounded block. The child constructed exactly one true d0500-minus geometry at R48, solved the four centered-CCW vertices for one h/valley batch, emitted a JSON start event and a compact JSON result event, deleted snapshots/provider objects, ran garbage collection, and exited normally. The supervisor verified exit code 0 and the final result event before accepting the output. It did not retain field arrays or automatically retry.

The harness was staging-only and was not added to the MePhC repository.

## Resource certification block 1

RESOURCE_CERT_BLOCK_1=PASS

Configuration:

    true d0500-minus; R=48; TM; six bands; mesh=3; tolerance=1e-7
    K=(0,-2/3); CENTERED_CCW; mpb_live_energy_eh_v1; h=0.01

Child exit code was 0 and output was complete. RSS was 133.10 MB at child start, 160.81 MB peak before cleanup, and 140.81 MB before child exit. The supervisor RSS was 14.75 MB before launch and 14.77 MB after child exit.

The four vertex frequency rows were:

    [0.2428767018, 0.3024719674, 0.3997250788, 0.4953096128, 0.6714545468, 0.6788916509]
    [0.2428767029, 0.3024719656, 0.3997250814, 0.4953096126, 0.6714545801, 0.6788916105]
    [0.2428775888, 0.3024718550, 0.3997246583, 0.4953097893, 0.6714413339, 0.6789075603]
    [0.2428775886, 0.3024718576, 0.3997246568, 0.4953097907, 0.6714413049, 0.6789076057]

Full-energy Gram max off-diagonal values were 1.09e-15, 1.29e-15, 2.41e-15, and 1.47e-15. Wilson phases for bands 1 and 2 were +0.00150157125 and -0.00093445754. The scaled modern values using `-phase/h^2` were:

    Omega1       = -15.01571251
    Omega2       =   9.34457543
    Omega_anti   = -12.18014397
    Omega_common =  -2.83556854
    common_ratio =   0.23280255

Qualification metrics:

    min_external_gap       = 0.09725280
    min_singular_value     = 0.99926339
    max_projector_distance = 0.03837536
    max_principal_angle    = 0.03838479 rad
    old_0.05_profile       = PASS
    scale-aware candidate  = NOT_APPLIED

## Resource certification block 2

RESOURCE_CERT_BLOCK_2=PASS

Configuration was identical to block 1 except h=0.001 and the child process was new. Child exit code was 0 and output was complete. RSS was 132.36 MB at start, 160.07 MB peak before cleanup, and 144.07 MB before child exit. The supervisor RSS after exit was 13.83 MB.

The four vertex frequency rows were:

    [0.2429148276, 0.3024646846, 0.3996854852, 0.4953226373, 0.6715964006, 0.6787505174]
    [0.2429148277, 0.3024646844, 0.3996854855, 0.4953226372, 0.6715964040, 0.6787505133]
    [0.2429147809, 0.3024648141, 0.3996854167, 0.4953226757, 0.6715948125, 0.6787524021]
    [0.2429147808, 0.3024648142, 0.3996854164, 0.4953226758, 0.6715948090, 0.6787524057]

Full-energy Gram max off-diagonal values were 1.86e-15, 1.21e-15, 1.53e-15, and 1.20e-15. Wilson phases were +1.50314925e-05 and -9.34683652e-06. The scaled modern values were:

    Omega1       = -15.03149254
    Omega2       =   9.34683652
    Omega_anti   = -12.18916453
    Omega_common =  -2.84232801
    common_ratio =   0.23318481

Qualification metrics:

    min_external_gap       = 0.09722060
    min_singular_value     = 0.99999278
    max_projector_distance = 0.00380078
    max_principal_angle    = 0.00380079 rad
    old_0.05_profile       = PASS
    scale-aware candidate  = NOT_APPLIED

## Modern physics sanity

TRUE_D0500_MODERN_SANITY=PASSED_WITH_REPRESENTATION_OR_PLAQUETTE_DIFFERENCE

Both centered E+H blocks are nonzero, have opposite dominant band signs, and remain at the same broad O(12) antisymmetric scale as the recovered historical forward H-only d0500 anchor (-12.14265). The h=.001 result is stable relative to h=.01 and has healthier link geometry. The common component is finite and has a plausible multiband ratio near 0.233. The frequency family and external gap agree with the recovered d0500 spectral family. The modern centered E+H result is not required to equal the old forward H-only value exactly.

## K-prime sign control

MODERN_SIGN_CONTROL=CONFIRMED

One new child was run at R48, h=.01, Kp=(0,+2/3), same d0500-minus domain and centered E+H convention. It exited 0 with complete output. It produced:

    Omega1       = +15.01564580
    Omega2       =  -9.34458178
    Omega_anti   = +12.18011379
    Omega_common =  +2.83553201
    common_ratio =  0.23280012

The K-prime anti component reverses sign without post-processing. Its min external gap was 0.09725280 and min singular value 0.99926339.

## Repeatability

RESOURCE_BATCH_REPEATABILITY=REPRODUCIBLE

A fresh repeat of block 1 returned the same exit code and the same compact numerical values to the reported precision:

    Omega_anti delta = 0.0
    common_ratio delta = 0.0
    min-gap delta = 0.0
    min-singular-value delta = 0.0
    peak RSS first/repeat = 160.8125 / 160.1015625 MB

## Certified lifecycle plan

D0500_MATRIX_EXECUTION_PLAN=FRESH_PROCESS_PER_SMALL_BATCH_READY

The measurements demonstrate safe isolation for one h/valley/domain batch containing four vertices. They do not demonstrate that multiple h values can safely coexist in one child, so a per-resolution long-lived worker is not certified. The certified next design is one fresh child per small batch, with compact incremental JSON, exit-code and completeness checks, RSS floor/ceiling checks, normal exit, and no hidden retry. A supervisor must refuse to start the next batch if the previous result is incomplete.

## Repository boundary

No tracked production file was modified. No commit or push was performed. Temporary worker scripts and result manifests were external staging artifacts only. Final repository verification:

    HEAD        = 3655ed050afd39a2befe5c739759a20af2a3036f
    origin/main = 3655ed050afd39a2befe5c739759a20af2a3036f
    worktree    = clean

No scientific semantics, thresholds, WSL configuration, or production code were changed.

## Required classifications

RUNTIME_RECOVERY=PASS
RESOURCE_CERT_BLOCK_1=PASS
RESOURCE_CERT_BLOCK_2=PASS
TRUE_D0500_MODERN_SANITY=PASSED_WITH_REPRESENTATION_OR_PLAQUETTE_DIFFERENCE
MODERN_SIGN_CONTROL=CONFIRMED
RESOURCE_BATCH_REPEATABILITY=REPRODUCIBLE
D0500_MATRIX_EXECUTION_PLAN=FRESH_PROCESS_PER_SMALL_BATCH_READY
C3_OVERALL=MODERN_SANITY_AND_RESOURCE_PATH_CERTIFIED

STOP_AFTER=E7I.1A.6.C3
The full convergence matrix remains unstarted and requires a new explicit supervisor work order.
