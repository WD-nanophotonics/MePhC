import json
import math
import sys
from pathlib import Path

import numpy as np

MPBBC = "/mnt/c/Users/icywo/Documents/workspace/MPBBC"
CBS = "/mnt/c/Users/icywo/Documents/workspace/CBS"
for p in (MPBBC, CBS):
    if p not in sys.path:
        sys.path.insert(0, p)

from bc_calculator import BC_calculator
from geo_gen import MeepGeometry

OUT = Path("/tmp/trilatt_e7i_ref3/legacy_manifest.json")
OUT.parent.mkdir(parents=True, exist_ok=True)
CASES = {
    "honeycomb": {"shape_type": "hc", "a": 400.0, "r1": 125.0, "r2": 100.0, "third_parameter": 100.0},
    "triangular": {"shape_type": "tri", "a": 400.0, "r1": 135.0, "r2": None, "third_parameter": None},
}

def cpx(z):
    return {"real": float(np.real(z)), "imag": float(np.imag(z))}

def make_geometry(spec):
    return MeepGeometry(spec["shape_type"], a=spec["a"], r1=spec["r1"], r2=spec["r2"], n_background=2.65, n_lattice=1.0, resolution=128)

def frequencies(calculator, k):
    solver = calculator.build_solver(k)
    solver.run_parity(calculator.mp.TE, False, calculator.mpb.fix_efield_phase)
    return [float(x) for x in solver.all_freqs]

def run_case(spec, step):
    geometry = make_geometry(spec)
    calculator = BC_calculator(geometry)
    k0 = np.array([2.0 / 3.0, 0.0], dtype=float)
    vertices = [k0, k0 + np.array([step, 0.0]), k0 + np.array([step, step]), k0 + np.array([0.0, step])]
    fields = []
    vertex_records = []
    for k in vertices:
        freqs = frequencies(calculator, k)
        efields, hfields = calculator.calculate_fields(k, n_bands=3)
        fields.append((efields, hfields))
        vertex_records.append({"k_cartesian": [float(x) for x in k], "frequencies": freqs[:3]})
    links = []
    for band in range(3):
        band_links = []
        for i, j in ((0, 1), (1, 2), (2, 3), (3, 0)):
            e0, h0 = fields[i]
            e1, h1 = fields[j]
            overlap = calculator.overlap(e0[band], h0[band], e1[band], h1[band])
            band_links.append(cpx(overlap))
        product = 1.0 + 0.0j
        for link in band_links:
            product *= complex(link["real"], link["imag"])
        phase = float(np.angle(product))
        links.append({"band": band + 1, "raw_links": band_links, "product": cpx(product), "phase": phase, "legacy_scalar": float(-phase / (step ** 2) / ((2.0 * math.pi) ** 2))})
    return {
        "geometry": {
            "constructor": "MeepGeometry", "shape_type": spec["shape_type"], "a": spec["a"], "r1": spec["r1"], "r2": spec["r2"],
            "n_background": 2.65, "n_lattice": 1.0, "resolution": 128,
            "lattice_basis": [[0.5, math.sqrt(3) / 2.0], [0.5, -math.sqrt(3) / 2.0]],
            "coordinate_convention": "legacy public Cartesian k; calculator converts with cartesian_to_reciprocal",
            "bloch_phase": False, "phase_callback": "mpb.fix_efield_phase",
            "energy_normalization": "epsilon-weighted E plus H",
            "materials": {"background_epsilon": 2.65 ** 2, "inclusion_epsilon": 1.0, "block_height": 1000.0},
            "source": "MPBBC/geo_gen.py + MPBBC/bc_gen.py",
        },
        "vertices": vertex_records,
        "links": links,
        "formula": "-imag(log(product))/step^2/(2*pi)^2",
        "normalization": "unit magnitude overlap links from epsilon-weighted E+H inner product",
    }

def main():
    manifest = {"work_order": "TRILATT-E7I1A-REF3-20260821-004", "source_root": MPBBC, "cases": [], "notes": ["Each case/step has two fresh BC_calculator/MPB solver instances.", "No repository files are written; this is a temporary external manifest."]}
    for case_name, spec in CASES.items():
        case_record = {"case": case_name, "spec": spec, "runs": []}
        for step in (0.001, 0.0005):
            for run_index in (1, 2):
                print(f"RUN {case_name} step={step} fresh={run_index}", flush=True)
                run = run_case(spec, step)
                run["step"] = step
                run["fresh_solver_instance"] = run_index
                case_record["runs"].append(run)
                OUT.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        manifest["cases"].append(case_record)
        OUT.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"WROTE {OUT}")

if __name__ == "__main__":
    main()
