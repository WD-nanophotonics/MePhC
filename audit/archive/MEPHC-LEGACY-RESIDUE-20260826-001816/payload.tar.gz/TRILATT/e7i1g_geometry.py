from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from shapely.geometry import Polygon
from shapely.ops import triangulate, unary_union


ROOT = Path("/mnt/c/Users/icywo/PycharmProjects/MePhC-Windows")
SQRT3 = math.sqrt(3.0)
G1 = np.array([1.0 / SQRT3, 1.0])
G2 = np.array([1.0 / SQRT3, -1.0])
K = np.array([0.0, -2.0 / 3.0])
KP = np.array([0.0, 2.0 / 3.0])
BZ = np.array([
    [0.0, -2.0 / 3.0],
    [1.0 / SQRT3, -1.0 / 3.0],
    [1.0 / SQRT3, 1.0 / 3.0],
    [0.0, 2.0 / 3.0],
    [-1.0 / SQRT3, 1.0 / 3.0],
    [-1.0 / SQRT3, -1.0 / 3.0],
])


def clip(poly, center, competitor, tol=1e-12):
    """Keep ||x-center|| <= ||x-competitor|| by Sutherland-Hodgman."""
    if not poly:
        return []
    direction = competitor - center
    bound = (float(np.dot(competitor, competitor)) - float(np.dot(center, center))) / 2.0

    def value(point):
        return float(np.dot(direction, point) - bound)

    output = []
    previous = np.asarray(poly[-1], dtype=float)
    previous_value = value(previous)
    previous_inside = previous_value <= tol
    for current_raw in poly:
        current = np.asarray(current_raw, dtype=float)
        current_value = value(current)
        current_inside = current_value <= tol
        if current_inside != previous_inside:
            fraction = previous_value / (previous_value - current_value)
            output.append(previous + fraction * (current - previous))
        if current_inside:
            output.append(current)
        previous, previous_value, previous_inside = current, current_value, current_inside
    return output


def copies(center, radius=3):
    return [center + n1 * G1 + n2 * G2 for n1 in range(-radius, radius + 1) for n2 in range(-radius, radius + 1)]


all_k = copies(K)
all_kp = copies(KP)
all_centers = all_k + all_kp
k_cells = []
for center in all_k:
    polygon = [point.copy() for point in BZ]
    for competitor in all_centers:
        if np.allclose(center, competitor, atol=1e-12):
            continue
        polygon = clip(polygon, center, competitor)
        if not polygon:
            break
    if len(polygon) >= 3 and Polygon([point.tolist() for point in polygon]).area > 1e-10:
        k_cells.append(Polygon([point.tolist() for point in polygon]))

region = unary_union(k_cells)
if region.geom_type == "Polygon":
    pieces = [region]
else:
    pieces = list(region.geoms)


def max_edge(triangle):
    points = np.asarray(triangle, dtype=float)
    return max(float(np.linalg.norm(points[(index + 1) % 3] - points[index])) for index in range(3))


def refine(triangle, limit):
    points = [np.asarray(point, dtype=float) for point in triangle]
    if max_edge(points) <= limit + 1e-12:
        return [tuple(tuple(float(value) for value in point) for point in points)]
    a, b, c = points
    ab, bc, ca = (a + b) / 2.0, (b + c) / 2.0, (c + a) / 2.0
    result = []
    for child in ((a, ab, ca), (ab, b, bc), (ca, bc, c), (ab, bc, ca)):
        result.extend(refine(child, limit))
    return result


def mesh(limit):
    triangles = []
    for piece in pieces:
        for triangle in triangulate(piece):
            if piece.covers(triangle.representative_point()):
                triangles.extend(refine(list(triangle.exterior.coords)[:3], limit))
    point_ids = {}
    points = []
    indexed_triangles = []
    for triangle in triangles:
        indices = []
        for point in triangle:
            key = tuple(round(value, 12) for value in point)
            if key not in point_ids:
                point_ids[key] = len(points)
                points.append(list(point))
            indices.append(point_ids[key])
        if len(set(indices)) == 3:
            indexed_triangles.append(indices)
    return {"points_abs": points, "points_offset_K": [[p[0] - K[0], p[1] - K[1]] for p in points], "triangles": indexed_triangles}


coarse = mesh(.06)
fine = mesh(.03)
area_bz = Polygon(BZ.tolist()).area
area_region = region.area
output = {
    "coordinate_space": "public_q=k_phys*a/(2*pi)",
    "reciprocal_basis": {"g1": G1.tolist(), "g2": G2.tolist()},
    "K": K.tolist(), "Kp": KP.tolist(), "bz_polygon": BZ.tolist(),
    "area_bz": area_bz, "area_voronoi_K": area_region, "expected_area_bz": 2.0 / SQRT3, "expected_area_voronoi_K": 1.0 / SQRT3,
    "pieces": [list(map(list, piece.exterior.coords))[:-1] for piece in pieces],
    "coarse": coarse, "fine": fine,
    "max_coarse_edge": max(max_edge([coarse["points_abs"][i] for i in triangle]) for triangle in coarse["triangles"]),
    "max_fine_edge": max(max_edge([fine["points_abs"][i] for i in triangle]) for triangle in fine["triangles"]),
    "tie_convention": "half_open_storage_boundary_measure_zero",
}
(ROOT / ".e7i1g_geometry.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
print(json.dumps({"event": "geometry_complete", "pieces": len(pieces), "area_bz": area_bz, "area_voronoi_K": area_region, "coarse_points": len(coarse["points_abs"]), "coarse_triangles": len(coarse["triangles"]), "fine_points": len(fine["points_abs"]), "fine_triangles": len(fine["triangles"]), "max_coarse_edge": output["max_coarse_edge"], "max_fine_edge": output["max_fine_edge"]}, indent=2))
