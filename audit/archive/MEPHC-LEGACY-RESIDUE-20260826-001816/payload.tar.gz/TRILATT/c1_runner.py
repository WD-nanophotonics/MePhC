from pathlib import Path

source_path = Path("/mnt/c/Users/icywo/PycharmProjects/MePhC-Windows/e7i1e_c1_analysis.py")
source = source_path.read_text(encoding="utf-8")
source = source.replace(
    'def result_rows(*, subset=None, valley="K", resolution=64, h=0.001):',
    'def result_rows(*, subset=None, valley="K", resolution=64, h=0.001, qmax=None):',
)
source = source.replace(
    '        if task.get("subset") == "sentinel_plus_R64":\n'
    '            continue\n'
    '        rows.append(task["result"])',
    '        if task.get("subset") == "sentinel_plus_R64":\n'
    '            continue\n'
    '        if qmax is not None and max(abs(task["result"]["target_q"][0]), abs(task["result"]["target_q"][1])) > qmax + EPS:\n'
    '            continue\n'
    '        rows.append(task["result"])',
)
source = source.replace("e7_fine_rows = result_rows()", "e7_fine_rows = result_rows(qmax=.06)")
exec(compile(source, str(source_path), "exec"))
