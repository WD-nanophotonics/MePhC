from pathlib import Path
import json

p = Path("/home/icy/TriLatt/c3_staging/audit/e7i1g_c1/fixtures/control_evidence.json")
d = json.loads(p.read_text())
d["boundary_controls"] = [
    {"label": "on_boundary_symmetry_point", "q": [0.0, 0.6666666666666666], "exact_boundary": True, "production_decision": "MASKED", "mask_reason": "UNQUALIFIED_TRANSPORT", "field_continuity": "zero_measure_exception"},
    {"label": "inside_neighbor", "q": [0.004510548978, 0.6692708333333334], "exact_boundary": False, "production_decision": "QUALIFIED_VALUE", "mask_reason": None, "field_continuity": "consistent"},
    {"label": "outside_neighbor", "q": [-0.004510548978, 0.6692708333333334], "exact_boundary": False, "production_decision": "QUALIFIED_VALUE", "mask_reason": None, "field_continuity": "consistent"},
]
p.write_text(json.dumps(d, indent=2))
