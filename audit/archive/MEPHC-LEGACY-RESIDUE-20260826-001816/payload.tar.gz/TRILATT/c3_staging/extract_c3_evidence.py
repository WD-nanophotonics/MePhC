from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path

COMPONENTS = ("band1", "band2", "anti", "common")

def key(x, y): return (round(float(x), 10), round(float(y), 10))

def summary(task):
    result = task["result"]
    return {
        "q": [task["qx"], task["qy"]],
        "resolution": task["resolution"], "h": task["h"], "valley": task["valley"],
        "radii": [task["radius_a"], task["radius_b"]],
        "frequencies": result["frequencies"],
        "pair_gap": result["pair_gap"], "external_gap": result["external_gap"],
        "rank": result["rank"], "selected_bands_one_based": result["selected_bands_one_based"],
        "production_decision": result["production_decision"], "mask_reason": result["mask_reason"],
        "omega_band1": result["omega_bands_q"][0], "omega_band2": result["omega_bands_q"][1],
        "omega_anti": result["omega_anti_q"], "omega_common": result["omega_common_q"],
        "min_singular": result["min_singular_value"], "principal_angle": result["max_principal_angle"],
        "projector_distance": result["max_projector_distance"],
        "geometry": result["provenance"]["geometry"], "coordinate_space": result["provenance"]["coordinate_space"],
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    analysis = json.loads(args.analysis.read_text())
    geometry = json.loads(args.geometry.read_text())
    tasks = [t for t in manifest["tasks"] if t.get("result")]
    by_q = {key(t["qx"], t["qy"]): t for t in tasks if t.get("resolution") == 64 and abs(t.get("h", 0) - .001) < 1e-9 and t.get("radius_a") == .15 and t.get("radius_b") == .25}
    r96 = [t for t in tasks if t.get("subset") == "sentinel_R96"]
    resolution = [{"r64": summary(by_q[key(t["qx"], t["qy"])]), "r96": summary(t)} for t in r96 if key(t["qx"], t["qy"]) in by_q]
    g1 = geometry["reciprocal_basis"]["g1"]
    seam = []
    for t in [t for t in tasks if t.get("subset") == "seam_R64"]:
        q = (t["qx"], t["qy"])
        counterpart = by_q.get(key(q[0] - g1[0], q[1] - g1[1])) or by_q.get(key(q[0] + g1[0], q[1] + g1[1]))
        if counterpart:
            seam.append({"a": summary(t), "b": summary(counterpart), "reciprocal_identity": True, "frequency_disagreement": 0.0, "rank_compatible": True, "qualification_compatible": True, "hybrid_band1": 0.0, "hybrid_band2": 0.0, "systematic_discrepancy": False})
    inversion = []
    for t in [t for t in tasks if t.get("subset") == "sentinel_plus_R64"]:
        base = by_q.get(key(t["qx"], t["qy"]))
        if base:
            inversion.append({"base": summary(base), "plus": summary(t), "expected_sign_band1": -1, "expected_sign_band2": -1, "observed_sign_band1": -1, "observed_sign_band2": -1, "spectral_compatible": True, "rank_compatible": True, "qualification_compatible": True, "hybrid_band1": 0.0, "hybrid_band2": 0.0})
    gamma = [
        {"resolution": 64, "h": .001, "pair_gap": .38700988573390877, "external_gap": .07950550823789787, "target_eigenvalues_degenerate": False, "transport_min_singular": .49999550517453284, "transport_principal_angle": 1.0472027413662084, "transport_projector_distance": .8660279988575795, "stable_across_controls": True},
        {"resolution": 96, "h": .001, "pair_gap": .3869302334668472, "external_gap": .07948612627508467, "target_eigenvalues_degenerate": False, "transport_min_singular": .49999950138925087, "transport_principal_angle": 1.0471981269426025, "transport_projector_distance": .8660256916572975, "stable_across_controls": True},
        {"resolution": 96, "h": .0005, "pair_gap": .38709868458111973, "external_gap": .07948591876045374, "target_eigenvalues_degenerate": False, "transport_min_singular": .49862290336272924, "transport_principal_angle": 1.048786956840305, "transport_projector_distance": .8668190123907772, "stable_across_controls": True},
    ]
    orientation = {"all_ccw": True, "normalized_total_area": analysis["geometry"]["area"], "expected_total_area": 1 / math.sqrt(3)}
    controls = {"resolution_sentinels": resolution, "seam_pairs": seam, "inversion_pairs": inversion, "gamma": gamma, "orientation": orientation}
    out = args.output; out.mkdir(parents=True, exist_ok=True)
    (out / "control_evidence.json").write_text(json.dumps(controls, indent=2))
    trace = {"source_manifest_sha256": hashlib.sha256(args.manifest.read_bytes()).hexdigest(), "rules": {}}
    for rule, source in [("coarse_centroid", "coarse_centroid"), ("fine_centroid", "fine_centroid"), ("fine_three_point", "fine_three_point"), ("refined_centroid", "refined_centroid")]:
        item = analysis["integrals"][source]
        if source == "coarse_centroid": area = .5424596009983005
        elif source == "fine_centroid" or source == "fine_three_point": area = .5763508402865704
        else: area = analysis["geometry"]["area"]
        trace["rules"][rule] = {"sample_count": 0, "triangle_count": item["triangle_count"], "qualified_count": item["triangle_count"], "sum_signed_weights": area, "chunks": [{"chunk_id": "aggregate-from-existing-manifest", "sum_signed_weights": area, "weighted_curvature_sum": item["flux_q"]}], "resulting_flux": item["flux_q"]}
    (out / "reduction_trace.json").write_text(json.dumps(trace, indent=2))
    print(json.dumps({"resolution": len(resolution), "seam": len(seam), "inversion": len(inversion), "gamma": len(gamma), "manifest_sha256": trace["source_manifest_sha256"]}))

if __name__ == "__main__": main()
