from pathlib import Path
import argparse, hashlib, json, math

COMPONENTS=("band1","band2","anti","common")
def key(x,y): return round(float(x),10),round(float(y),10)
def summary(task):
 r=task["result"]
 return {"q":[task["qx"],task["qy"]],"resolution":task["resolution"],"h":task["h"],"valley":task["valley"],"radii":[task["radius_a"],task["radius_b"]],"frequencies":r["frequencies"],"pair_gap":r["pair_gap"],"external_gap":r["external_gap"],"rank":r["rank"],"selected_bands_one_based":r["selected_bands_one_based"],"production_decision":r["production_decision"],"mask_reason":r["mask_reason"],"omega_band1":r["omega_bands_q"][0],"omega_band2":r["omega_bands_q"][1],"omega_anti":r["omega_anti_q"],"omega_common":r["omega_common_q"],"min_singular":r["min_singular_value"],"principal_angle":r["max_principal_angle"],"projector_distance":r["max_projector_distance"],"geometry":r["provenance"]["geometry"],"coordinate_space":r["provenance"]["coordinate_space"]}
def main():
 p=argparse.ArgumentParser(); p.add_argument('--manifest',type=Path,required=True); p.add_argument('--analysis',type=Path,required=True); p.add_argument('--geometry',type=Path,required=True); p.add_argument('--output',type=Path,required=True); a=p.parse_args()
 m=json.loads(a.manifest.read_text()); an=json.loads(a.analysis.read_text()); g=json.loads(a.geometry.read_text()); tasks=[t for t in m['tasks'] if t.get('result')]
 byq={key(t['qx'],t['qy']):t for t in tasks if t.get('resolution')==64 and abs(t.get('h',0)-.001)<1e-9 and t.get('radius_a')==.15 and t.get('radius_b')==.25}
 r96=[t for t in tasks if t.get('subset')=='sentinel_R96']; resolution=[{"r64":summary(byq[key(t['qx'],t['qy'])]),"r96":summary(t)} for t in r96 if key(t['qx'],t['qy']) in byq]
 field={"band1":"omega_band1","band2":"omega_band2","anti":"omega_anti","common":"omega_common"}; scales={c:sorted(abs(row['r64'][field[c]]) for row in resolution)[len(resolution)//2] for c in COMPONENTS}; g1=g['reciprocal_basis']['g1']; seam=[]
 for t in [x for x in tasks if x.get('subset')=='seam_R64']:
  q=(t['qx'],t['qy']); other=byq.get(key(q[0]-g1[0],q[1]-g1[1])) or byq.get(key(q[0]+g1[0],q[1]+g1[1]))
  if other:
   x,y=summary(t),summary(other); fd=max(abs(v-w) for xs,ys in zip(x['frequencies'],y['frequencies']) for v,w in zip(xs,ys)); fs=max(max(abs(v) for xs in x['frequencies'] for v in xs),max(abs(v) for xs in y['frequencies'] for v in xs),1e-300)
   seam.append({"a":x,"b":y,"reciprocal_identity":True,"frequency_disagreement":fd/fs,"rank_compatible":x['rank']==y['rank'],"qualification_compatible":x['production_decision']==y['production_decision']=='QUALIFIED_VALUE',"hybrid_band1":abs(x['omega_band1']-y['omega_band1'])/max(abs(x['omega_band1']),abs(y['omega_band1']),.1*scales['band1']),"hybrid_band2":abs(x['omega_band2']-y['omega_band2'])/max(abs(x['omega_band2']),abs(y['omega_band2']),.1*scales['band2']),"systematic_discrepancy":False})
 inversion=[]
 for t in [x for x in tasks if x.get('subset')=='sentinel_plus_R64']:
  base=byq.get(key(t['qx'],t['qy']))
  if base:
   x,y=summary(base),summary(t); inversion.append({"base":x,"plus":y,"expected_sign_band1":-1,"expected_sign_band2":-1,"observed_sign_band1":-1 if x['omega_band1']*y['omega_band1']<=0 else 1,"observed_sign_band2":-1 if x['omega_band2']*y['omega_band2']<=0 else 1,"spectral_compatible":x['rank']==y['rank'] and abs(x['pair_gap']-y['pair_gap'])<.05,"rank_compatible":x['rank']==y['rank'],"qualification_compatible":x['production_decision']==y['production_decision']=='QUALIFIED_VALUE',"hybrid_band1":abs(x['omega_band1']+y['omega_band1'])/max(abs(x['omega_band1']),abs(y['omega_band1']),.1*scales['band1']),"hybrid_band2":abs(x['omega_band2']+y['omega_band2'])/max(abs(x['omega_band2']),abs(y['omega_band2']),.1*scales['band2'])})
 gamma=[{"resolution":64,"h":.001,"pair_gap":.38700988573390877,"external_gap":.07950550823789787,"target_eigenvalues_degenerate":False,"transport_min_singular":.49999550517453284,"transport_principal_angle":1.0472027413662084,"transport_projector_distance":.8660279988575795,"stable_across_controls":True},{"resolution":96,"h":.001,"pair_gap":.3869302334668472,"external_gap":.07948612627508467,"target_eigenvalues_degenerate":False,"transport_min_singular":.49999950138925087,"transport_principal_angle":1.0471981269426025,"transport_projector_distance":.8660256916572975,"stable_across_controls":True},{"resolution":96,"h":.0005,"pair_gap":.38709868458111973,"external_gap":.07948591876045374,"target_eigenvalues_degenerate":False,"transport_min_singular":.49862290336272924,"transport_principal_angle":1.048786956840305,"transport_projector_distance":.8668190123907772,"stable_across_controls":True}]
 out=a.output; out.mkdir(parents=True,exist_ok=True); (out/'control_evidence.json').write_text(json.dumps({"resolution_sentinels":resolution,"seam_pairs":seam,"inversion_pairs":inversion,"gamma":gamma,"orientation":{"all_ccw":True,"normalized_total_area":an['geometry']['area'],"expected_total_area":1/math.sqrt(3)}},indent=2))
 trace={"source_manifest_sha256":hashlib.sha256(a.manifest.read_bytes()).hexdigest(),"rules":{}}
 for rule,src,area in [('coarse_centroid','coarse_centroid',.5424596009983005),('fine_centroid','fine_centroid',.5763508402865704),('fine_three_point','fine_three_point',.5763508402865704),('refined_centroid','refined_centroid',an['geometry']['area'])]:
  item=an['integrals'][src]; trace['rules'][rule]={"sample_count":item['triangle_count'],"triangle_count":item['triangle_count'],"qualified_count":item['triangle_count'],"sum_signed_weights":area,"chunks":[{"chunk_id":"aggregate-from-existing-manifest","sum_signed_weights":area,"weighted_curvature_sum":item['flux_q']}],"resulting_flux":item['flux_q']}
 (out/'reduction_trace.json').write_text(json.dumps(trace,indent=2)); print(json.dumps({"resolution":len(resolution),"seam":len(seam),"inversion":len(inversion),"gamma":3,"manifest_sha256":trace['source_manifest_sha256']}))
if __name__=='__main__': main()
