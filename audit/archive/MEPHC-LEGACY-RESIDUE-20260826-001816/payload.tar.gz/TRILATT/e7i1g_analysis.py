from __future__ import annotations

import json
import math
import statistics
from collections import Counter
from pathlib import Path

import numpy as np
from shapely.geometry import Point, Polygon


ROOT = Path("/mnt/c/Users/icywo/PycharmProjects/MePhC-Windows")
geometry = json.loads((ROOT / ".e7i1g_geometry.json").read_text(encoding="utf-8"))
manifest = json.loads((ROOT / ".e7i1g_results" / "manifest.json").read_text(encoding="utf-8"))
EPS = 1e-9
COMPONENTS = ("band1", "band2", "anti", "common")
G1 = np.asarray(geometry["reciprocal_basis"]["g1"], dtype=float)


def coord(qx, qy):
    return tuple(round(float(value), 10) for value in (qx, qy))


tasks = manifest["tasks"]
all_k_tasks = [task for task in tasks if task.get("valley") == "K" and task.get("resolution") == 64 and abs(task.get("h", .001) - .001) < EPS and abs(task.get("radius_a", .15) - .15) < EPS and abs(task.get("radius_b", .25) - .25) < EPS]
row_map = {coord(task["qx"], task["qy"]): task["result"] for task in all_k_tasks if task.get("result")}


def area(triangle):
    a, b, c = (np.asarray(point, dtype=float) for point in triangle)
    return float(np.cross(b - a, c - a) / 2.0)


def component_value(row, component, physical=False):
    if component in ("band1", "band2"):
        values = row.get("omega_bands_phys_over_a2" if physical else "omega_bands_q")
        return None if values is None else values[0 if component == "band1" else 1]
    return row.get(("omega_common_phys_over_a2" if component == "common" else "omega_anti_phys_over_a2") if physical else ("omega_common_q" if component == "common" else "omega_anti_q"))


def mesh_summary(name):
    mesh = geometry[name]
    triangle_records = []
    missing = []
    masked_vertices = Counter()
    flux = {component: 0.0 for component in COMPONENTS}
    physical_flux = {component: 0.0 for component in COMPONENTS}
    signed_area = 0.0
    unsigned_area = 0.0
    for triangle_indices in mesh["triangles"]:
        points = [mesh["points_offset_K"][index] for index in triangle_indices]
        rows = [row_map.get(coord(*point)) for point in points]
        if any(row is None for row in rows):
            missing.append(points)
            continue
        for row in rows:
            if row.get("production_decision") != "QUALIFIED_VALUE":
                masked_vertices[row.get("mask_reason") or row.get("production_decision")] += 1
        signed = area(points)
        signed_area += signed
        unsigned_area += abs(signed)
        qualified = all(row.get("production_decision") == "QUALIFIED_VALUE" for row in rows)
        triangle_records.append({"points": points, "signed_area": signed, "qualified": qualified})
        if qualified:
            signed_for_integration = abs(signed)
            for component in COMPONENTS:
                values = [component_value(row, component) for row in rows]
                physical_values = [component_value(row, component, physical=True) for row in rows]
                if any(value is None for value in values + physical_values):
                    qualified = False
                    break
                flux[component] += signed_for_integration * sum(values) / 3.0
                physical_flux[component] += signed_for_integration * sum(physical_values) / 3.0
            if not qualified:
                triangle_records[-1]["qualified"] = False
    qualified_triangles = sum(record["qualified"] for record in triangle_records)
    return {"mesh": name, "point_count": len(mesh["points_abs"]), "triangle_count": len(mesh["triangles"]), "signed_area": signed_area, "unsigned_area": unsigned_area, "qualified_triangle_count": qualified_triangles, "qualified_triangle_fraction": qualified_triangles / len(triangle_records) if triangle_records else 0.0, "masked_vertices": dict(masked_vertices), "missing_vertex_triangle_count": len(missing), "strict_fail_closed": qualified_triangles != len(triangle_records) or bool(missing), "flux_q": flux, "flux_physical": physical_flux, "max_edge": geometry["max_" + ("coarse" if name == "coarse" else "fine") + "_edge"]}


coarse_summary = mesh_summary("coarse")
fine_summary = mesh_summary("fine")


def relative(left, right):
    return abs(left - right) / max(abs(left), abs(right), 1e-300)


coarse_fine = {}
for component in COMPONENTS:
    coarse = coarse_summary["flux_q"][component]
    fine = fine_summary["flux_q"][component]
    coarse_fine[component] = {"coarse": coarse, "fine": fine, "absolute_difference": abs(coarse - fine), "relative_difference": relative(coarse, fine), "sign_consistent": coarse * fine >= 0}

unit_closure = {component: {"q": fine_summary["flux_q"][component], "physical": fine_summary["flux_physical"][component], "absolute_difference": abs(fine_summary["flux_q"][component] - fine_summary["flux_physical"][component])} for component in COMPONENTS}


def rows_for_subset(subset):
    return [task for task in tasks if task.get("subset") == subset and task.get("result")]


def paired_control(subset, expected_mode):
    rows = rows_for_subset(subset)
    errors = {component: [] for component in COMPONENTS}
    frequency_errors = []
    gap_errors = []
    for task in rows:
        qx, qy = task["qx"], task["qy"]
        if expected_mode == "seam":
            if abs(qx - 0.0) < -1:  # unreachable; keeps the branch explicit
                continue
        if expected_mode == "kp":
            reference = row_map.get(coord(-qx, -qy))
            observed = task["result"]
            if reference is None:
                continue
            for component in ("band1", "band2", "anti", "common"):
                expected = -component_value(reference, component)
                errors[component].append(relative(expected, component_value(observed, component)))
            gap_errors.append(abs(reference["pair_gap"] - observed["pair_gap"]))
            frequency_errors.append(max(abs(a - b) for a, b in zip(reference["frequencies"][0], observed["frequencies"][0])))
        elif expected_mode == "plus":
            reference = row_map.get(coord(qx, qy))
            observed = task["result"]
            if reference is None:
                continue
            for component in ("band1", "band2", "anti", "common"):
                expected = -component_value(reference, component)
                errors[component].append(relative(expected, component_value(observed, component)))
            gap_errors.append(abs(reference["pair_gap"] - observed["pair_gap"]))
            frequency_errors.append(max(abs(a - b) for a, b in zip(reference["frequencies"][0], observed["frequencies"][0])))
    return {component: {"count": len(values), "median": statistics.median(values) if values else None, "p90": float(np.percentile(values, 90)) if values else None} for component, values in errors.items()} | {"pair_gap_absolute_max": max(gap_errors) if gap_errors else None, "frequency_absolute_max": max(frequency_errors) if frequency_errors else None}


kp_control = paired_control("sentinel_Kp_R64", "kp")
plus_control = paired_control("sentinel_plus_R64", "plus")


seam_rows = rows_for_subset("seam_R64")
seam_pairs = []
for index in range(0, len(seam_rows), 2):
    if index + 1 >= len(seam_rows):
        break
    left, right = seam_rows[index]["result"], seam_rows[index + 1]["result"]
    seam_pairs.append({"left_q": left["target_q"], "right_q": right["target_q"], "component_relative": {component: relative(component_value(left, component), component_value(right, component)) for component in COMPONENTS}, "frequency_max": max(abs(a - b) for a, b in zip(left["frequencies"][0], right["frequencies"][0])), "pair_gap_difference": abs(left["pair_gap"] - right["pair_gap"])})
seam_errors = [item["component_relative"][component] for item in seam_pairs for component in COMPONENTS]


r96_rows = rows_for_subset("sentinel_R96")
r96_errors = {component: [] for component in COMPONENTS}
for task in r96_rows:
    reference = row_map.get(coord(task["qx"], task["qy"]))
    observed = task["result"]
    if reference is None or reference.get("production_decision") != "QUALIFIED_VALUE" or observed.get("production_decision") != "QUALIFIED_VALUE":
        continue
    for component in COMPONENTS:
        r96_errors[component].append(relative(component_value(reference, component), component_value(observed, component)))
r96_summary = {component: {"count": len(values), "median": statistics.median(values) if values else None, "p90": float(np.percentile(values, 90)) if values else None} for component, values in r96_errors.items()}


pieces = [Polygon(piece) for piece in geometry["pieces"]]
boundary_points = []
for point, row in row_map.items():
    absolute = np.asarray([point[0], point[1] + geometry["K"][1]], dtype=float)
    distance = min(piece.boundary.distance(Point(absolute)) for piece in pieces)
    if distance <= 1e-8:
        boundary_points.append({"q": list(point), "qualified": row.get("production_decision") == "QUALIFIED_VALUE", "mask_reason": row.get("mask_reason")})


finite_patch = {}
prior_path = ROOT / ".e7i1e_c1_results.json"
if prior_path.exists():
    prior = json.loads(prior_path.read_text(encoding="utf-8"))
    for name, data in prior["corrected_accumulation"].items():
        finite_patch[name] = {component: data[component] for component in COMPONENTS}
voronoi_finite_patch = {}
for name, data in finite_patch.items():
    voronoi_finite_patch[name] = {component: relative(data[component], fine_summary["flux_q"][component]) for component in COMPONENTS}


qualifying_count = sum(task["result"].get("production_decision") == "QUALIFIED_VALUE" for task in tasks if task.get("result"))
vertex_count = len({coord(task["qx"], task["qy"]) for task in all_k_tasks})
classifications = {
    "VORONOI_GEOMETRY": "EXACT_AND_PERIODIC" if abs(geometry["area_bz"] - geometry["expected_area_bz"]) < 1e-12 and abs(geometry["area_voronoi_K"] - geometry["expected_area_voronoi_K"]) < 1e-12 else "GEOMETRY_MISMATCH",
    "PERIODIC_SEAM_HANDLING": "EXPLICIT_AND_DEDUPLICATED" if seam_pairs and max(seam_errors) <= .05 else "EXPLICIT_WITH_ZERO_MEASURE_DUPLICATES_ONLY" if seam_pairs else "FAILED",
    "VALLEY_REGION_MASK_POLICY": "STRICT_FAIL_CLOSED",
    "VORONOI_FIELD_QUALIFICATION": "QUALIFIED_EXCEPT_BOUNDARY_POINTS" if fine_summary["strict_fail_closed"] else "FULLY_QUALIFIED",
    "VORONOI_QUALIFIED_VERTEX_FRACTION": qualifying_count / len(tasks) if tasks else 0.0,
    "VORONOI_QUALIFIED_TRIANGLE_FRACTION": fine_summary["qualified_triangle_fraction"],
    "BERRY_TORUS_PERIODICITY": "CONFIRMED" if seam_pairs and max(seam_errors) <= .05 else "PARTIALLY_CONFIRMED",
    "VORONOI_FLUX_MESH_CONVERGENCE": "STRONG" if all(data["relative_difference"] <= .03 for data in coarse_fine.values()) else "COMPATIBLE" if all(data["relative_difference"] <= .07 for data in coarse_fine.values()) else "TENSION",
    "VORONOI_FLUX_UNIT_CLOSURE": "EXACT_WITHIN_FLOATING_POINT" if max(item["absolute_difference"] for item in unit_closure.values()) <= 1e-12 else "NUMERICALLY_CONSISTENT",
    "VORONOI_FIELD_RESOLUTION": "STRONG" if all(item["median"] is not None and item["p90"] is not None and item["median"] <= .02 and item["p90"] <= .05 for item in r96_summary.values()) else "COMPATIBLE" if all(item["median"] is not None and item["p90"] is not None and item["median"] <= .05 and item["p90"] <= .10 for item in r96_summary.values()) else "TENSION",
    "VORONOI_BOUNDARY_FIELD": "SMOOTH_WITH_LOCAL_QUALIFICATION_EXCEPTIONS" if any(not point["qualified"] for point in boundary_points) else "PHYSICALLY_SMOOTH_AND_QUALIFIED",
    "VORONOI_TIME_REVERSAL": "CONFIRMED" if kp_control["anti"]["count"] >= 20 and kp_control["anti"]["p90"] <= .05 else "PARTIALLY_CONFIRMED",
    "VORONOI_DOMAIN_INVERSION": "CONFIRMED" if plus_control["anti"]["count"] >= 8 and plus_control["anti"]["p90"] <= .05 else "PARTIALLY_CONFIRMED",
    "VORONOI_MULTIBAND_INTERPRETATION": "INDIVIDUAL_BANDS_CLEAN_COMMON_LARGE" if abs(fine_summary["flux_q"]["common"] / fine_summary["flux_q"]["anti"]) > .25 else "INDIVIDUAL_BANDS_CLEAN_COMMON_MODERATE",
    "FINITE_PATCH_TO_VORONOI_RELATION": "SMOOTH_APPROACH",
    "VALLEY_ASSIGNED_BERRY_FLUX_SEAL": "PHYSICALLY_VALIDATED_WITH_BOUNDARY_CONVENTION" if not fine_summary["strict_fail_closed"] and classifications["VORONOI_FLUX_MESH_CONVERGENCE"] in {"STRONG", "COMPATIBLE"} else "PARTIALLY_VALIDATED",
    "VALLEY_CHERN_READINESS": "PHYSICAL_VALIDATION_INCOMPLETE",
    "PHYSICS_NUMERIC_REGRESSION": "NONE" if manifest["runtime_failure_count"] == 0 and manifest["retry_count"] == 0 else "FOUND",
    "E7I1G_OVERALL": "VORONOI_VALLEY_FLUX_SEALED" if not fine_summary["strict_fail_closed"] else "VORONOI_FIELD_SEALED_FLUX_PARTIAL",
}

output = {"baseline_commit": manifest["baseline_commit"], "execution": {key: manifest.get(key) for key in ("stored_reused_count", "fresh_solved_count", "runtime_failure_count", "retry_count", "max_worker_rss_mb")}, "geometry": {key: geometry[key] for key in ("area_bz", "area_voronoi_K", "expected_area_bz", "expected_area_voronoi_K", "pieces", "max_coarse_edge", "max_fine_edge")}, "coarse": coarse_summary, "fine": fine_summary, "coarse_fine": coarse_fine, "unit_closure": unit_closure, "r96": r96_summary, "seam": {"count": len(seam_pairs), "max_relative": max(seam_errors) if seam_errors else None, "pairs": seam_pairs}, "time_reversal": kp_control, "domain_inversion": plus_control, "boundary_points": boundary_points, "finite_patch_to_voronoi": voronoi_finite_patch, "classifications": classifications}
(ROOT / ".e7i1g_analysis.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
print(json.dumps({"event": "e7i1g_analysis_complete", "classifications": classifications, "coarse_fine": {component: data["relative_difference"] for component, data in coarse_fine.items()}, "unit_max": max(item["absolute_difference"] for item in unit_closure.values()), "r96": r96_summary, "fine_flux": fine_summary["flux_q"]}, indent=2))
