import json

from gmail_courier.config import home_dir
from gmail_courier.core import DeliveryExpectation, sync_until_received


def report(status):
    print(json.dumps(status, ensure_ascii=False), flush=True)


outcome = sync_until_received(
    home_dir(),
    max_seconds=360,
    interval_seconds=10,
    on_poll=report,
    expected=DeliveryExpectation(
        "TRILATT",
        "R66AMePhCResult02C8A53",
        "R66A_RESULT_02C8A53",
        "result.json",
        "TRILATT-R66AMePhCResult02C8A53-1",
    ),
    lookback_seconds=1200,
)
print(json.dumps(outcome, ensure_ascii=False), flush=True)
