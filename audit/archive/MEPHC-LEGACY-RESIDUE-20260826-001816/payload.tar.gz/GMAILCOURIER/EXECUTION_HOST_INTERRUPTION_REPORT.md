# Courier execution-host interruption report

## Scope

This report covers `courier_interrupted` with
`interruption_stage=pre_browser`. It is not a ChatGPT, Chrome, queue, Gmail,
or payload failure.

## Meaning of the event

Courier emits this event only after Python catches `KeyboardInterrupt` while
handling the request. At the pre-browser stage the durable record also proves:

- `browser_started=false`;
- no Courier browser owner was recorded;
- no user turn was submitted; and
- the immutable request may be retried once without duplicating external work.

The event records the Courier PID and parent PID so the execution host can
identify the process chain that delivered Ctrl+C.

## Required host behavior

The host must run the project-approved single Courier bridge in a process
session that remains alive for the configured queue allowance, setup allowance,
response window, and grace period. The default combined allowance is 4,860
seconds. It must preserve the child while the request is queued, submitted, and
waiting for a reply.

## What not to do

Do not try to evade cancellation with `nohup`, `setsid`, hidden/background
processes, another browser, another profile, Gmail, a second request ID, or a
different Chat URL. Those actions either bypass the project transport boundary
or create uncertain duplicate external state.

## Escalation criterion

After the same immutable request reports a second pre-browser interruption,
stop retrying from that execution host. Report the latest `receipt.json` and
the corresponding `events.jsonl` entries to the host/runtime maintainer. The
maintainer must fix the parent process or command runner that sends Ctrl+C;
Courier cannot safely ignore a host cancellation signal.
